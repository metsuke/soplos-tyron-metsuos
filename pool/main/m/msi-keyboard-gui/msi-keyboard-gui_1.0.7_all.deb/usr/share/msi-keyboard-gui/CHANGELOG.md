# Changelog

Todos los cambios notables de este proyecto se documentarán en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es/1.0.0/),
y este proyecto se adhiere a [Semantic Versioning](https://semver.org/lang/es/).

## [1.0.7] - 2025-07-27

### 🎨 Cambiado - Icono principal
- Cambio de icono principal del programa para mejor integración visual.

## [1.0.6] - 2025-07-18

### 🛠️ Mejorado - Metainfo y compatibilidad AppStream/DEP-11
- Actualización de metainfo para cumplir con AppStream/DEP-11.
- Correcciones menores en la estructura y etiquetas del metainfo.
- Validación completa para centros de software.

## [1.0.5] - 2025-07-05

### 🔧 Mejorado - Gestión de servicios systemd
- Script unificado para todas las operaciones systemd con una sola autenticación pkexec.
- Eliminación automática de archivos temporales después de crear servicios.
- Mejoras en el manejo de errores y estabilidad general del sistema.

## [1.0.4] - 2025-07-05

### 🔒 Seguridad y UX
- Uso de pkexec para autenticación gráfica al crear servicios systemd.
- Mejor manejo de cancelación de autenticación por parte del usuario.
- Correcciones menores y mejoras de estabilidad.

## [1.0.3] - 2025-06-26

### 🚀 Mejorado - Integración systemd
- Generación y actualización automática del servicio systemd al aplicar configuración.
- El servicio systemd se habilita para aplicar la configuración RGB al arrancar.
- Correcciones menores y mejoras de integración.

## [1.0.2] - 2025-06-24

### 📝 Documentación y metadatos
- Actualización de versión y metadatos.
- Mejoras menores.

## [1.0.1] - 2025-06-24

### 🛠️ Mejorado - Integración AppStream
- Ahora la aplicación es visible en Discover y otras tiendas AppStream.
- Mejoras en los metadatos AppStream.

## [1.0.0] - 2024-12-19

### 🎉 Lanzamiento Inicial
- Interfaz gráfica GTK3 para configurar teclados MSI RGB.
- Configuración visual por zonas con vista previa en tiempo real.
- Soporte para múltiples modos de iluminación.
- Guardado y carga de configuraciones.
- Soporte multiidioma (Español/Inglés).
- Compatible con XFCE, Plasma y GNOME.
- Depende del paquete msi-keyboard para funcionalidad de hardware.

---

## Tipos de Cambios

- **Añadido** para nuevas características
- **Cambiado** para cambios en funcionalidad existente
- **Obsoleto** para características que serán eliminadas
- **Eliminado** para características eliminadas
- **Corregido** para corrección de errores
- **Seguridad** para vulnerabilidades

## Contribuir

Para reportar errores o solicitar características:
- **Issues**: https://github.com/SoplosLinux/tyron/issues
- **Email**: info@soploslinux.com

## Soporte

- **Documentación**: https://soploslinux.com/docs/msi-keyboard-gui
- **Comunidad**: https://soploslinux.com/community
- **Support**: support@soploslinux.com
