"""Módulo GUI para MSI Keyboard RGB Controller"""
