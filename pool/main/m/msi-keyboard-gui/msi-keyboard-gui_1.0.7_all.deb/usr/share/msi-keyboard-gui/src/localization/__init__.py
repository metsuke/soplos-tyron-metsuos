"""Sistema de localización para MSI Keyboard RGB Controller"""
