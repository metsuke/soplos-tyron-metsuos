import os
import sys
from pathlib import Path

def get_assets_path():
    """
    Obtiene la ruta correcta de assets dependiendo del contexto de ejecución
    
    Returns:
        str: Ruta absoluta al directorio assets
    """
    # Intentar diferentes ubicaciones según el contexto
    possible_paths = [
        # Durante desarrollo (ejecutando desde el directorio del proyecto)
        os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'assets'),
        
        # Después de instalación con pip/setuptools
        os.path.join(sys.prefix, 'share', 'msi-keyboard'),
        
        # Instalación del sistema
        os.path.join('/usr', 'share', 'msi-keyboard'),
        
        # Instalación local
        os.path.join('/usr', 'local', 'share', 'msi-keyboard'),
        
        # Fallback relativo al archivo actual
        os.path.join(os.path.dirname(__file__), '..', '..', 'assets'),
    ]
    
    for path in possible_paths:
        abs_path = os.path.abspath(path)
        if os.path.exists(abs_path):
            return abs_path
    
    # Si no se encuentra ninguna ruta, usar la primera como fallback
    return os.path.abspath(possible_paths[0])

def get_asset_file(filename):
    """
    Obtiene la ruta completa a un archivo específico en assets
    
    Args:
        filename (str): Nombre del archivo (puede incluir subdirectorios)
        
    Returns:
        str: Ruta completa al archivo
    """
    assets_dir = get_assets_path()
    return os.path.join(assets_dir, filename)

def get_icon_path(icon_name):
    """
    Obtiene la ruta a un icono específico
    
    Args:
        icon_name (str): Nombre del archivo de icono
        
    Returns:
        str: Ruta completa al icono
    """
    return get_asset_file(os.path.join('icons', icon_name))

def get_project_root():
    """
    Obtiene la ruta raíz del proyecto
    
    Returns:
        str: Ruta absoluta al directorio raíz del proyecto
    """
    # Navegar hacia arriba desde src/utils/paths.py hasta la raíz
    current_file = os.path.abspath(__file__)
    return os.path.dirname(os.path.dirname(os.path.dirname(current_file)))
