import gi
import os
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GdkPixbuf
import math
import cairo

from ..utils.paths import get_asset_file

class KeyboardWidget(Gtk.DrawingArea):
    def __init__(self, zones, colors, click_callback):
        super().__init__()
        self.zones = zones
        self.colors = colors
        self.click_callback = click_callback
        self.selected_zone = 'left'
        self.set_size_request(800, 280)
        self.set_hexpand(True)
        self.set_vexpand(True)
        self.connect("draw", self.on_draw)
        self.connect("button-press-event", self.on_button_press)
        self.set_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.keyboard_image = None
        self.image_width = 0
        self.image_height = 0
        self.image_x = 0
        self.image_y = 0
        self.original_zones = {
            'left': {'x': 50, 'y': 160, 'width': 240, 'height': 100},
            'middle': {'x': 310, 'y': 160, 'width': 280, 'height': 100},
            'right': {'x': 610, 'y': 160, 'width': 240, 'height': 100}
        }
        try:
            img_path = get_asset_file('keyboard.png')
            if os.path.exists(img_path):
                self.keyboard_image = GdkPixbuf.Pixbuf.new_from_file(img_path)
                self.original_width = self.keyboard_image.get_width()
                self.original_height = self.keyboard_image.get_height()
            else:
                from ..localization.strings import get_string
                print(f"{get_string('keyboard_image_not_found')}: {img_path}")
        except Exception as e:
            from ..localization.strings import get_string
            print(f"{get_string('keyboard_image_load_error')}: {e}")

    def on_draw(self, widget, cr):
        width = widget.get_allocated_width()
        height = widget.get_allocated_height()
        
        # Fondo con gradiente profesional
        self._draw_gradient_background(cr, width, height)
        
        if self.keyboard_image:
            self._draw_keyboard_with_image(cr, width, height)
        else:
            self._draw_professional_keyboard(cr, width, height)

    def _draw_gradient_background(self, cr, width, height):
        """Dibuja un fondo con gradiente profesional"""
        gradient = cairo.LinearGradient(0, 0, 0, height)
        gradient.add_color_stop_rgb(0, 0.05, 0.05, 0.08)
        gradient.add_color_stop_rgb(1, 0.12, 0.12, 0.16)
        cr.set_source(gradient)
        cr.rectangle(0, 0, width, height)
        cr.fill()

    def _draw_keyboard_with_image(self, cr, width, height):
        # Calcular escala y posición
        scale_x = (width - 40) / self.original_width
        scale_y = (height - 40) / self.original_height
        self.scale = min(scale_x, scale_y)
        self.image_width = int(self.original_width * self.scale)
        self.image_height = int(self.original_height * self.scale)
        self.image_x = (width - self.image_width) // 2
        self.image_y = (height - self.image_height) // 2

        # Sombra del teclado
        self._draw_shadow(cr, self.image_x, self.image_y, self.image_width, self.image_height)

        # CAMBIADO: Primero dibujar las zonas RGB (abajo)
        self._draw_professional_zones(cr, use_image_coords=True)

        # MOVIDO: Luego dibujar la imagen del teclado encima (con transparencias)
        scaled_image = self.keyboard_image.scale_simple(
            self.image_width, self.image_height, GdkPixbuf.InterpType.BILINEAR
        )
        Gdk.cairo_set_source_pixbuf(cr, scaled_image, self.image_x, self.image_y)
        cr.paint()

    def _draw_shadow(self, cr, x, y, width, height):
        """Dibuja una sombra profesional"""
        shadow_offset = 8
        shadow_blur = 12
        
        # Crear patrón radial para la sombra
        shadow_pattern = cairo.RadialGradient(
            x + width/2, y + height/2, 0,
            x + width/2, y + height/2, max(width, height)/2 + shadow_blur
        )
        shadow_pattern.add_color_stop_rgba(0, 0, 0, 0, 0.3)
        shadow_pattern.add_color_stop_rgba(1, 0, 0, 0, 0)
        
        cr.set_source(shadow_pattern)
        self._draw_rounded_rect(cr, x + shadow_offset, y + shadow_offset, width, height, 15)
        cr.fill()

    def _draw_professional_zones(self, cr, use_image_coords=False):
        """Dibuja zonas RGB con efectos profesionales"""
        if use_image_coords and self.keyboard_image:
            zone_areas = {}
            # CORREGIDO: Usar exactamente el tamaño de la imagen dividido en 3
            zone_width = self.original_width // 3
            for i, zone_name in enumerate(['left', 'middle', 'right']):
                zone_areas[zone_name] = {
                    'x': self.image_x + (i * zone_width * self.scale),
                    'y': self.image_y + (0 * self.scale),
                    'width': zone_width * self.scale,
                    'height': self.original_height * self.scale
                }
        else:
            zone_areas = {}
            for zone_name, orig_coords in self.original_zones.items():
                zone_areas[zone_name] = {
                    'x': self.image_x + (orig_coords['x'] * self.scale),
                    'y': self.image_y + (orig_coords['y'] * self.scale),
                    'width': orig_coords['width'] * self.scale,
                    'height': orig_coords['height'] * self.scale
                }

        for zone_name, area in zone_areas.items():
            zone_config = self.zones[zone_name]
            color_hex = self.colors[zone_config['color']]
            r = int(color_hex[1:3], 16) / 255.0
            g = int(color_hex[3:5], 16) / 255.0
            b = int(color_hex[5:7], 16) / 255.0
            
            intensity_factor = {'light': 0.4, 'low': 0.6, 'med': 0.8, 'high': 1.0}
            factor = intensity_factor.get(zone_config['intensity'], 1.0)
            
            # Efecto de brillo interno
            self._draw_glow_effect(cr, area, r * factor, g * factor, b * factor)
            
            # Zona principal con gradiente
            self._draw_zone_gradient(cr, area, r * factor, g * factor, b * factor)
            
            # Borde brillante
            self._draw_zone_border(cr, area, r * factor, g * factor, b * factor)
            
            # Indicador de selección mejorado
            if zone_name == self.selected_zone:
                self._draw_selection_indicator(cr, area)
        
        self.zone_areas = zone_areas

    def _draw_glow_effect(self, cr, area, r, g, b):
        """Dibuja efecto de brillo alrededor de la zona"""
        glow_size = 15
        glow_pattern = cairo.RadialGradient(
            area['x'] + area['width']/2, area['y'] + area['height']/2, 0,
            area['x'] + area['width']/2, area['y'] + area['height']/2, 
            max(area['width'], area['height'])/2 + glow_size
        )
        glow_pattern.add_color_stop_rgba(0, r, g, b, 0.4)
        glow_pattern.add_color_stop_rgba(0.7, r, g, b, 0.1)
        glow_pattern.add_color_stop_rgba(1, r, g, b, 0)
        
        cr.set_source(glow_pattern)
        self._draw_rounded_rect(cr, 
            area['x'] - glow_size, area['y'] - glow_size,
            area['width'] + 2*glow_size, area['height'] + 2*glow_size, 12)
        cr.fill()

    def _draw_zone_gradient(self, cr, area, r, g, b):
        """Dibuja la zona con gradiente interno"""
        gradient = cairo.LinearGradient(
            area['x'], area['y'], 
            area['x'], area['y'] + area['height']
        )
        gradient.add_color_stop_rgba(0, r, g, b, 0.7)
        gradient.add_color_stop_rgba(0.5, r, g, b, 0.4)
        gradient.add_color_stop_rgba(1, r, g, b, 0.6)
        
        cr.set_source(gradient)
        self._draw_rounded_rect(cr, area['x'], area['y'], area['width'], area['height'], 8)
        cr.fill()

    def _draw_zone_border(self, cr, area, r, g, b):
        """Dibuja el borde brillante de la zona"""
        cr.set_source_rgba(r, g, b, 0.9)
        cr.set_line_width(2)
        self._draw_rounded_rect(cr, area['x'], area['y'], area['width'], area['height'], 8)
        cr.stroke()

    def _draw_selection_indicator(self, cr, area):
        """Dibuja indicador de selección animado"""
        # Anillo externo pulsante
        cr.set_source_rgba(1, 1, 1, 0.8)
        cr.set_line_width(3)
        self._draw_rounded_rect(cr, 
            area['x'] - 4, area['y'] - 4, 
            area['width'] + 8, area['height'] + 8, 12)
        cr.stroke()
        
        # Puntos de esquina brillantes
        corner_size = 6
        corners = [
            (area['x'] - corner_size//2, area['y'] - corner_size//2),
            (area['x'] + area['width'] - corner_size//2, area['y'] - corner_size//2),
            (area['x'] - corner_size//2, area['y'] + area['height'] - corner_size//2),
            (area['x'] + area['width'] - corner_size//2, area['y'] + area['height'] - corner_size//2)
        ]
        
        cr.set_source_rgba(0.2, 0.8, 1, 0.9)
        for x, y in corners:
            cr.arc(x, y, corner_size//2, 0, 2 * math.pi)
            cr.fill()

    def _draw_professional_keyboard(self, cr, width, height):
        """Dibuja un teclado profesional sin imagen"""
        margin = 25
        kb_width = width - 2*margin
        kb_height = height - 2*margin
        kb_x = margin
        kb_y = margin
        
        # Sombra del teclado
        self._draw_shadow(cr, kb_x, kb_y, kb_width, kb_height)
        
        # Base del teclado con gradiente
        gradient = cairo.LinearGradient(kb_x, kb_y, kb_x, kb_y + kb_height)
        gradient.add_color_stop_rgb(0, 0.2, 0.2, 0.25)
        gradient.add_color_stop_rgb(0.5, 0.15, 0.15, 0.20)
        gradient.add_color_stop_rgb(1, 0.1, 0.1, 0.15)
        cr.set_source(gradient)
        self._draw_rounded_rect(cr, kb_x, kb_y, kb_width, kb_height, 15)
        cr.fill()
        
        # Borde metálico
        cr.set_source_rgba(0.4, 0.4, 0.45, 0.8)
        cr.set_line_width(2)
        self._draw_rounded_rect(cr, kb_x, kb_y, kb_width, kb_height, 15)
        cr.stroke()
        
        # Zonas RGB profesionales
        zone_margin = 20
        zone_y = kb_y + zone_margin
        zone_height = kb_height - 2*zone_margin
        
        zone_areas = {
            'left': {
                'x': kb_x + zone_margin,
                'y': zone_y,
                'width': kb_width * 0.28,
                'height': zone_height
            },
            'middle': {
                'x': kb_x + zone_margin + kb_width * 0.32,
                'y': zone_y,
                'width': kb_width * 0.36,
                'height': zone_height
            },
            'right': {
                'x': kb_x + zone_margin + kb_width * 0.72,
                'y': zone_y,
                'width': kb_width * 0.25,
                'height': zone_height
            }
        }
        
        for zone_name, area in zone_areas.items():
            zone_config = self.zones[zone_name]
            color_hex = self.colors[zone_config['color']]
            r = int(color_hex[1:3], 16) / 255.0
            g = int(color_hex[3:5], 16) / 255.0
            b = int(color_hex[5:7], 16) / 255.0
            
            intensity_factor = {'light': 0.4, 'low': 0.6, 'med': 0.8, 'high': 1.0}
            factor = intensity_factor.get(zone_config['intensity'], 1.0)
            
            # Aplicar efectos profesionales
            self._draw_glow_effect(cr, area, r * factor, g * factor, b * factor)
            self._draw_zone_gradient(cr, area, r * factor, g * factor, b * factor)
            self._draw_zone_border(cr, area, r * factor, g * factor, b * factor)
            
            if zone_name == self.selected_zone:
                self._draw_selection_indicator(cr, area)
        
        self.zone_areas = zone_areas

    def _draw_rounded_rect(self, cr, x, y, width, height, radius):
        """Dibuja un rectángulo con esquinas redondeadas"""
        if width < 2 * radius or height < 2 * radius:
            radius = min(width, height) / 2
        cr.new_sub_path()
        cr.arc(x + radius, y + radius, radius, math.pi, 3 * math.pi / 2)
        cr.arc(x + width - radius, y + radius, radius, 3 * math.pi / 2, 0)
        cr.arc(x + width - radius, y + height - radius, radius, 0, math.pi / 2)
        cr.arc(x + radius, y + height - radius, radius, math.pi / 2, math.pi)
        cr.close_path()

    def on_button_press(self, widget, event):
        """Maneja los clics en las zonas del teclado"""
        if not hasattr(self, 'zone_areas'):
            return
        for zone_name, area in self.zone_areas.items():
            if (area['x'] <= event.x <= area['x'] + area['width'] and
                area['y'] <= event.y <= area['y'] + area['height']):
                # RESTAURADO: Mostrar diálogo de configuración directamente
                self._show_zone_config_dialog(zone_name)
                break
    
    def _show_zone_config_dialog(self, zone_name):
        """Muestra un diálogo para configurar la zona seleccionada"""
        from src.localization.strings import get_string
        
        # Crear ventana de diálogo
        dialog = Gtk.Dialog(
            title=f"{get_string('zone_config')} - {get_string(zone_name).upper()}",
            parent=self.get_toplevel(),
            flags=0,
            buttons=(
                get_string('cancel'), Gtk.ResponseType.CANCEL,
                get_string('apply'), Gtk.ResponseType.OK
            )
        )

        dialog.set_default_size(350, 250)
        dialog.set_resizable(False)
        
        # Contenido del diálogo
        content_area = dialog.get_content_area()
        content_area.set_spacing(10)
        content_area.set_border_width(10)
        
        # Selector de color
        color_frame = Gtk.Frame(label=get_string('color'))
        color_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        color_box.set_border_width(10)
        
        color_combo = Gtk.ComboBoxText()
        current_color = self.zones[zone_name]['color']
        active_index = 0
        
        # CORREGIDO: Mostrar nombres traducidos pero mantener valores en inglés
        for i, color_name in enumerate(self.colors.keys()):
            color_combo.append(color_name, get_string(color_name))  # valor, texto mostrado
            if color_name == current_color:
                active_index = i
        color_combo.set_active(active_index)
        
        # AÑADIDO: Vista previa del color que estaba faltando
        color_preview = Gtk.DrawingArea()
        color_preview.set_size_request(100, 30)
        
        def update_preview(*args):
            color_preview.queue_draw()
        
        def draw_preview(widget, cr):
            selected_color_id = color_combo.get_active_id()
            if selected_color_id and selected_color_id in self.colors:
                color_hex = self.colors[selected_color_id]
                r = int(color_hex[1:3], 16) / 255.0
                g = int(color_hex[3:5], 16) / 255.0
                b = int(color_hex[5:7], 16) / 255.0
                cr.set_source_rgb(r, g, b)
                cr.rectangle(0, 0, widget.get_allocated_width(), widget.get_allocated_height())
                cr.fill()
        
        color_preview.connect("draw", draw_preview)
        color_combo.connect("changed", update_preview)
        
        color_box.pack_start(color_combo, False, False, 0)
        color_box.pack_start(color_preview, False, False, 0)
        color_frame.add(color_box)
        
        # Selector de intensidad
        intensity_frame = Gtk.Frame(label=get_string('intensity'))
        intensity_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        intensity_box.set_border_width(10)
        
        intensity_combo = Gtk.ComboBoxText()
        current_intensity = self.zones[zone_name]['intensity']
        intensities = ['light', 'low', 'med', 'high']
        intensity_active = 0
        
        # CORREGIDO: Mostrar nombres traducidos pero mantener valores en inglés
        for i, intensity in enumerate(intensities):
            intensity_combo.append(intensity, get_string(intensity))  # valor, texto mostrado
            if intensity == current_intensity:
                intensity_active = i
        intensity_combo.set_active(intensity_active)
        
        intensity_box.pack_start(intensity_combo, False, False, 0)
        intensity_frame.add(intensity_box)
        
        # Añadir al diálogo
        content_area.pack_start(color_frame, False, False, 0)
        content_area.pack_start(intensity_frame, False, False, 0)
        
        dialog.show_all()
        
        # Manejar respuesta
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            # CORREGIDO: Obtener el ID/valor, no el texto mostrado
            new_color = color_combo.get_active_id()
            new_intensity = intensity_combo.get_active_id()
            
            # Actualizar zona
            self.zones[zone_name]['color'] = new_color
            self.zones[zone_name]['intensity'] = new_intensity
            
            # Actualizar zona seleccionada y redibujar
            self.selected_zone = zone_name
            self.queue_draw()
            
            # Llamar callback si existe
            if self.click_callback:
                self.click_callback(zone_name)
        
        dialog.destroy()

    def set_selected_zone(self, zone_name):
        """Establece la zona seleccionada"""
        self.selected_zone = zone_name
        self.queue_draw()

    def update_zone_color(self, zone_name, color):
        """Actualiza el color de una zona"""
        self.zones[zone_name]['color'] = color
        self.queue_draw()

    def reset_colors(self, zones):
        """Resetea todos los colores"""
        self.zones = zones
        self.queue_draw()
        self.queue_draw()
        self.zones = zones
        self.queue_draw()
        self.queue_draw()
