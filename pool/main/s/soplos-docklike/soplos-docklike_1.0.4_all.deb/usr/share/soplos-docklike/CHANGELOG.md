# Changelog

Todos los cambios notables de este proyecto se documentarán en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es/1.0.0/),
y este proyecto se adhiere a [Semantic Versioning](https://semver.org/lang/es/).

## [1.0.4] - 2025-07-27

### 🆕 Cambiado
- Cambio de icono del programa.

## [1.0.3] - 2025-07-18

### 🛠️ Mejorado - Metainfo y compatibilidad AppStream/DEP-11
- Actualización de versión y metainfo para AppStream/DEP-11.
- Mejoras menores de integración y documentación.

## [1.0.0] - 2025-05-08

### 🎉 Lanzamiento Inicial
- Versión inicial de lanzamiento.
- Gestión y organización de iconos en el plugin Docklike del panel XFCE.
- Interfaz gráfica intuitiva.
- Soporte multiidioma (Español, Inglés, Francés, Portugués, Alemán, Italiano, Ruso, Rumano).

---

## Tipos de Cambios

- **Añadido** para nuevas características
- **Cambiado** para cambios en funcionalidad existente
- **Obsoleto** para características que serán eliminadas
- **Eliminado** para características eliminadas
- **Corregido** para corrección de errores
- **Seguridad** para vulnerabilidades

## Contribuir

Para reportar errores o solicitar características:
- **Issues**: https://github.com/SoplosLinux/tyron/issues
- **Email**: info@soploslinux.com

## Soporte

- **Documentación**: https://soploslinux.com/docs/soplos-docklike
- **Comunidad**: https://soploslinux.com/community
- **Support**: info@soploslinux.com
