# Application Manager for Docklike

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.4-green.svg)]()

Una herramienta gráfica para gestionar y organizar los iconos en el plugin Docklike del panel de XFCE.

*A graphical tool to manage and organize icons in the XFCE panel's Docklike plugin.*

## 📝 Descripción

Soplos Docklike es un gestor de iconos para el dock de XFCE que permite organizar y personalizar fácilmente las aplicaciones en el panel.

## ✨ Características

- Organización de iconos en el panel XFCE
- Personalización de aplicaciones en el plugin Docklike
- Interfaz gráfica intuitiva
- Soporte para múltiples idiomas

## 📸 Capturas de pantalla

### Ventana principal de Soplos Docklike
![Ventana principal](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-docklike/screenshots/screenshot1.png)

### Ajustes de iconos en Docklike
![Ajustes de iconos](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-docklike/screenshots/screenshot2.png)

## 🔧 Instalación

```bash
# Instrucciones de instalación pendientes
```

## 🌐 Idiomas soportados

- Español
- Inglés
- Francés
- Portugués
- Alemán
- Italiano
- Ruso
- Rumano

## 📄 Licencia

Este proyecto está licenciado bajo [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html) (GNU General Public License versión 3 o posterior).

Esta licencia garantiza las siguientes libertades:
- La libertad de usar el programa para cualquier propósito
- La libertad de estudiar cómo funciona el programa y modificarlo
- La libertad de distribuir copias del programa
- La libertad de mejorar el programa y publicar esas mejoras

Cualquier trabajo derivado debe distribuirse bajo la misma licencia (GPL-3.0+).

Para más detalles, consulte el archivo LICENSE o visite [gnu.org/licenses/gpl-3.0](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Desarrolladores

Desarrollado por [Sergi Perich](https://soploslinux.com)

## 🔗 Enlaces

- [Página web](https://soploslinux.com)
- [Reportar problemas](https://github.com/SoplosLinux/tyron/issues)
- [Ayuda](https://soploslinux.com)

## 📦 Versiones

### v1.0.4 (27/07/2025)
- Cambio de icono del programa.

### v1.0.3 (18/07/2025)
- Actualización de versión y metainfo para AppStream/DEP-11.
- Mejoras menores de integración y documentación.

### v1.0.0 (08/05/2025)
- Versión inicial de lanzamiento
