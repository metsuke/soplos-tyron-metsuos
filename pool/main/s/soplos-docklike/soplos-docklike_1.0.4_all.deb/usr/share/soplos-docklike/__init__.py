"""
Docklike - Organizador de iconos para el plugin Docklike de XFCE
"""