import os
import glob
import logging
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path

# Configurar logging solo para warnings y errores
logging.basicConfig(
    level=logging.WARNING,
    format='%(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Función para encontrar el archivo de configuración
def find_config_file():
    """Encuentra el archivo de configuración del panel"""
    try:
        xfce_panel_dir = Path.home() / ".config/xfce4/panel"
        if not xfce_panel_dir.exists():
            return None

        # Buscar específicamente docklike-1.rc primero
        default_config = xfce_panel_dir / "docklike-1.rc"
        if default_config.exists():
            return str(default_config)

        # Si no existe, buscar cualquier archivo docklike-*.rc
        docklike_configs = list(xfce_panel_dir.glob("docklike-*.rc"))
        if docklike_configs:
            return str(docklike_configs[0])
        
        # Si no existe ninguno, crearlo
        default_config.parent.mkdir(parents=True, exist_ok=True)
        default_config.write_text("[user]\npinned=\n")
        return str(default_config)
        
    except Exception as e:
        logger.error(f"Error buscando archivo de configuración: {e}")
        return None

# Directorios donde buscar archivos .desktop
DESKTOP_DIRS = [
    "/usr/share/applications",
    str(Path.home() / ".local/share/applications"),
    "/var/lib/snapd/desktop/applications",
    "/var/lib/flatpak/exports/share/applications",
    str(Path.home() / ".local/share/flatpak/exports/share/applications")
]

def expand_desktop_dirs():
    """Expande los directorios de aplicaciones"""
    return DESKTOP_DIRS  # Ya no necesitamos expandir porque Path.home() ya lo hace

def find_desktop_file(app_id):
    """Busca el archivo .desktop completo dado un ID de aplicación"""
    for dir in expand_desktop_dirs():
        if not os.path.exists(dir):
            continue
            
        # Buscar coincidencia exacta
        exact_match = os.path.join(dir, f"{app_id}.desktop")
        if os.path.exists(exact_match):
            return exact_match
            
        # Buscar coincidencia parcial
        for file in os.listdir(dir):
            if file.lower().endswith('.desktop') and app_id.lower() in file.lower():
                return os.path.join(dir, file)
    
    return None

# Rutas de configuración
CONFIG_FILE = find_config_file()
APPLICATIONS_DIR = "/usr/share/applications"

# Rutas de búsqueda de iconos
ICON_SEARCH_PATHS = [
    '/usr/share/icons/hicolor/48x48/apps',
    '/usr/share/icons/hicolor/scalable/apps',
    '/usr/share/pixmaps',
    '/usr/share/icons/gnome/48x48/apps',
    '/usr/share/icons/Adwaita/48x48/apps',
    '/usr/share/app-install/icons',
    str(Path.home() / ".local/share/icons"),
    '/usr/local/share/icons',
    '/var/lib/flatpak/exports/share/icons',
    str(Path.home() / ".local/share/flatpak/exports/share/icons"),
    '/var/lib/flatpak/exports/share/icons/hicolor/48x48/apps',
    '/var/lib/flatpak/exports/share/icons/hicolor/scalable/apps',
    str(Path.home() / ".local/share/flatpak/exports/share/icons/hicolor/48x48/apps"),
    str(Path.home() / ".local/share/flatpak/exports/share/icons/hicolor/scalable/apps")
]

# Asegurar que estas variables están disponibles para importación
__all__ = ['CONFIG_FILE', 'APPLICATIONS_DIR', 'ICON_SEARCH_PATHS', 'logger']