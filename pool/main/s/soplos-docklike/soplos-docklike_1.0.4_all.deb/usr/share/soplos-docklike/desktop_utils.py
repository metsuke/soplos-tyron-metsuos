import os
import sys
from gi.repository import Gio

# Ajustar path para importaciones absolutas
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Cambiar las importaciones relativas por absolutas
from config import logger
from utils.icon_utils import find_icon_in_system

def get_icon_name_from_desktop(desktop_file):
    """Obtiene el nombre del icono desde un archivo .desktop"""
    try:
        app_info = Gio.DesktopAppInfo.new_from_filename(desktop_file)
        if app_info:
            icon = app_info.get_icon()
            if icon:
                return icon.to_string()
    except Exception as e:
        logger.error(f"Error crítico al leer .desktop: {e}")

    try:
        with open(desktop_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.lower().startswith("icon="):
                    return line.split('=')[1].strip()
    except Exception as e:
        logger.error(f"Error crítico al leer archivo: {e}")

    return os.path.basename(desktop_file).replace('.desktop', '')

def get_app_name_from_desktop(desktop_file):
    """Obtiene el nombre de la aplicación desde un archivo .desktop"""
    try:
        app_info = Gio.DesktopAppInfo.new_from_filename(desktop_file)
        if app_info:
            return app_info.get_name()
    except Exception as e:
        logger.debug(f"Error obteniendo nombre de aplicación: {e}")
    
    try:
        with open(desktop_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.lower().startswith("name="):
                    return line.split('=')[1].strip()
    except Exception:
        pass
    
    return os.path.basename(desktop_file).replace('.desktop', '')

def get_icon_name_and_path(desktop_file):
    """Obtiene el nombre del icono y su ruta desde un archivo .desktop"""
    if not desktop_file or not desktop_file.strip():
        return None, None

    icon_name = get_icon_name_from_desktop(desktop_file)
    icon_path = find_icon_in_system(icon_name) if icon_name else None
    
    logger.debug(f"Resultado final - Nombre: {icon_name}, Ruta: {icon_path}")
    return icon_name, icon_path