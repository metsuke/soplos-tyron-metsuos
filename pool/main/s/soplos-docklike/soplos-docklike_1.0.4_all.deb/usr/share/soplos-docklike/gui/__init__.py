"""
Módulo de interfaz gráfica para Docklike
"""