import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GdkPixbuf, Gio
import os
import sys

# Asegurar que podemos importar desde el directorio raíz
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import APPLICATIONS_DIR, logger
from utils.icon_utils import get_icon_name_and_path
from translations.lang_utils import get_translation as _

class AppSelectorDialog(Gtk.Dialog):
    def __init__(self, parent):
        Gtk.Dialog.__init__(
            self, 
            title=_("select_apps_title"),
            transient_for=parent,
            flags=0,
            buttons=(
                Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                Gtk.STOCK_OK, Gtk.ResponseType.OK
            )
        )

        # Establecer un tamaño más grande para el diálogo
        self.set_default_size(600, 500)
        self.set_modal(True)
        
        box = self.get_content_area()
        box.set_spacing(6)
        
        # Etiqueta de instrucción
        label = Gtk.Label(label=_("select_apps_header", "Select the applications you want to add:"))
        label.set_margin_top(10)
        label.set_margin_bottom(5)
        box.add(label)
        
        # Añadir barra de búsqueda
        search_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        search_box.set_margin_start(10)
        search_box.set_margin_end(10)
        search_box.set_margin_bottom(10)
        
        search_label = Gtk.Label(label=_("search_label", "Search:"))
        search_box.pack_start(search_label, False, False, 0)
        
        self.search_entry = Gtk.Entry()
        self.search_entry.set_placeholder_text(_("search_placeholder"))
        self.search_entry.connect("changed", self.on_search_changed)
        search_box.pack_start(self.search_entry, True, True, 0)
        
        box.add(search_box)
        
        # Crear ScrolledWindow para la lista
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_margin_top(5)
        scrolled.set_margin_bottom(10)
        scrolled.set_margin_start(10)
        scrolled.set_margin_end(10)
        scrolled.set_min_content_height(350)  # Altura mínima para ver varias aplicaciones
        box.add(scrolled)
        
        # Modelo de lista con casillas de verificación
        self.liststore = Gtk.ListStore(bool, str, GdkPixbuf.Pixbuf, str)  # (seleccionado, nombre, pixbuf, ruta)
        
        # Crear la vista de la lista
        self.treeview = Gtk.TreeView(model=self.liststore)
        self.treeview.set_headers_visible(True)  # Mostrar encabezados para mejor visualización
        
        # Agregar una columna de casilla de verificación
        renderer_toggle = Gtk.CellRendererToggle()
        renderer_toggle.connect("toggled", self.on_cell_toggled)
        column_toggle = Gtk.TreeViewColumn("", renderer_toggle, active=0)
        self.treeview.append_column(column_toggle)
        
        # Agregar una columna para el icono
        renderer_pixbuf = Gtk.CellRendererPixbuf()
        column_icon = Gtk.TreeViewColumn(_("column_icon"), renderer_pixbuf, pixbuf=2)
        self.treeview.append_column(column_icon)
        
        # Agregar una columna para el nombre
        renderer_text = Gtk.CellRendererText()
        column_text = Gtk.TreeViewColumn(_("column_app"), renderer_text, text=1)
        column_text.set_expand(True)  # Permitir que la columna se expanda
        column_text.set_min_width(300)  # Establecer un ancho mínimo para la columna de nombre
        self.treeview.append_column(column_text)
        
        # Ordenar por nombre
        self.liststore.set_sort_column_id(1, Gtk.SortType.ASCENDING)
        
        scrolled.add(self.treeview)
        
        # Agregar indicador de estado
        status_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        status_box.set_margin_start(10)
        status_box.set_margin_end(10)
        status_box.set_margin_bottom(10)
        
        self.status_label = Gtk.Label(label=_("loading_apps"))
        status_box.pack_start(self.status_label, False, False, 0)
        
        # Botón para seleccionar/deseleccionar todas
        self.select_all_button = Gtk.Button(label=_("select_all"))
        self.select_all_button.connect("clicked", self.toggle_select_all)
        status_box.pack_end(self.select_all_button, False, False, 0)
        
        box.add(status_box)
        
        # Mostrar todo
        self.show_all()
        
        # Cargar aplicaciones DESPUÉS de crear todos los elementos de la interfaz
        self.load_applications()
        
        # Focus en el campo de búsqueda
        self.search_entry.grab_focus()

    def load_applications(self):
        """Carga todas las aplicaciones disponibles en el directorio de aplicaciones"""
        desktop_files = set()
        
        # Directorios donde buscar aplicaciones
        search_dirs = [
            APPLICATIONS_DIR,
            os.path.expanduser("~/.local/share/applications"),
            "/var/lib/flatpak/exports/share/applications",
            os.path.expanduser("~/.local/share/flatpak/exports/share/applications"),
            "/var/lib/snapd/desktop/applications"
        ]
        
        # Recolectar archivos .desktop válidos
        for directory in search_dirs:
            if not os.path.exists(directory):
                continue
                
            for filename in os.listdir(directory):
                if filename.endswith(".desktop"):
                    filepath = os.path.join(directory, filename)
                    # Ignorar archivos .desktop conocidos que causan problemas
                    if any(x in filename for x in ['kiod', 'kded', 'vim.desktop']):
                        continue
                    desktop_files.add(filepath)
        
        # Actualizar estado inicial usando traducción
        self.status_label.set_text(_("loading_apps"))
        loaded_count = 0
        added_apps = set()
        
        # Cargar aplicaciones
        for desktop_file in desktop_files:
            try:
                # Verificar si el archivo es válido antes de cargarlo
                if not os.path.exists(desktop_file) or os.path.getsize(desktop_file) == 0:
                    continue
                    
                app_info = Gio.DesktopAppInfo.new_from_filename(desktop_file)
                if not app_info:
                    continue
                    
                # Verificar que es una aplicación válida y visible
                if (app_info and 
                    not app_info.get_nodisplay() and 
                    not app_info.get_is_hidden() and
                    app_info.get_name()):
                    
                    app_name = app_info.get_name()
                    if app_name in added_apps:
                        continue
                        
                    icon_name, icon_path = get_icon_name_and_path(desktop_file)
                    pixbuf = self.load_icon(icon_path)
                    
                    if pixbuf and app_name:
                        self.liststore.append([False, app_name, pixbuf, desktop_file])
                        added_apps.add(app_name)
                        loaded_count += 1
                        
            except Exception as e:
                # Solo registrar errores importantes
                if "constructor returned NULL" not in str(e):
                    logger.warning(f"Error cargando {desktop_file}: {e}")
        
        # Asegurar que todos los mensajes de estado usen traducciones
        if loaded_count == 0:
            self.status_label.set_text(_("no_results"))
        else:
            self.status_label.set_text(_("showing_results").format(loaded_count))

    def load_icon(self, icon_path):
        """Carga el icono desde el path especificado y lo convierte en un Pixbuf"""
        try:
            if (icon_path and os.path.exists(icon_path)):
                return GdkPixbuf.Pixbuf.new_from_file_at_size(icon_path, 48, 48)
            
            default_icon = "/usr/share/icons/hicolor/48x48/apps/application-default-icon.png"
            if os.path.exists(default_icon):
                return GdkPixbuf.Pixbuf.new_from_file_at_size(default_icon, 48, 48)
                
        except Exception as e:
            logger.error(f"Error crítico cargando icono: {e}")
        return None

    def on_cell_toggled(self, widget, path):
        """Cambia el estado de selección cuando se hace clic en la casilla"""
        model = self.treeview.get_model()
        
        if isinstance(model, Gtk.TreeModelFilter):
            # Convertir path del modelo filtrado al modelo original
            child_path = model.convert_path_to_child_path(Gtk.TreePath(path))
            self.liststore[child_path][0] = not self.liststore[child_path][0]
        else:
            # Modelo normal
            self.liststore[path][0] = not self.liststore[path][0]
        
        # Actualizar el contador de seleccionados
        self.update_selection_count()

    def update_selection_count(self):
        """Actualiza el contador de aplicaciones seleccionadas"""
        selected_count = sum(1 for row in self.liststore if row[0])
        model = self.treeview.get_model()
        
        if isinstance(model, Gtk.TreeModelFilter):
            visible_count = len([row for row in model])
            self.status_label.set_text(_("selected_count").format(selected_count, visible_count))
        else:
            self.status_label.set_text(_("selected_count").format(selected_count, len(self.liststore)))

    def toggle_select_all(self, widget):
        """Selecciona o deselecciona todas las aplicaciones visibles"""
        model = self.treeview.get_model()
        select_all = _("select_all") in self.select_all_button.get_label()
        
        if isinstance(model, Gtk.TreeModelFilter):
            # Recorrer el modelo filtrado y cambiar las selecciones
            for row in model:
                child_iter = model.convert_iter_to_child_iter(row.iter)
                self.liststore[child_iter][0] = select_all
        else:
            # Modelo normal
            for row in self.liststore:
                row[0] = select_all
        
        # Actualizar el botón y el contador
        if select_all:
            self.select_all_button.set_label(_("deselect_all"))
        else:
            self.select_all_button.set_label(_("select_all"))
        
        self.update_selection_count()

    def on_search_changed(self, widget):
        """Filtra la lista según el texto de búsqueda"""
        search_text = widget.get_text().lower()
        
        # Si el modelo tiene un filtro, quitarlo primero
        model = self.treeview.get_model()
        if isinstance(model, Gtk.TreeModelFilter):
            original_model = model.get_model()
            self.treeview.set_model(original_model)
        
        # Si hay texto de búsqueda, aplicar filtro
        if search_text:
            filter_model = self.liststore.filter_new()
            filter_model.set_visible_func(
                lambda model, iter, data: search_text in model[iter][1].lower()
            )
            self.treeview.set_model(filter_model)
            
            # Contar los resultados filtrados usando texto traducido
            visible_count = len([row for row in filter_model])
            if visible_count == 0:
                self.status_label.set_text(_('no_results'))
            else:
                self.status_label.set_text(_('showing_results').format(visible_count))
        else:
            # Si no hay texto, mostrar todo
            self.treeview.set_model(self.liststore)
            
            # Restablecer el contador
            self.update_selection_count()
        
        # Restablecer el botón de seleccionar todo
        self.select_all_button.set_label(_("select_all"))

    def get_selected_apps(self):
        """Devuelve una lista de rutas de las aplicaciones seleccionadas"""
        selected_apps = []
        
        # Recorrer todas las filas en el liststore original
        for row in self.liststore:
            if row[0]:  # Si está seleccionado
                selected_apps.append(row[3])
        
        return selected_apps