"""Módulo que implementa la ventana principal de la aplicación."""

import os
import gi
import shutil
import dbus

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, GdkPixbuf, Gdk  # Añadido GLib

# Importaciones locales
from config import CONFIG_FILE, logger, find_desktop_file  # Añadido find_desktop_file
from desktop_utils import get_app_name_from_desktop
from utils.icon_utils import get_icon_name_and_path
from gui.app_selector import AppSelectorDialog
from translations.lang_utils import get_translation as _

ASSETS_DIR = os.path.join(os.path.dirname(__file__), '..', 'assets')
# Cambiar la ruta del logo al icono específico de la aplicación
ICON_FILE = os.path.join("icons", "soplos-docklike.png")  # Nombre correcto del icono

class IconListWindow(Gtk.ApplicationWindow):  # Cambiar a Gtk.ApplicationWindow
    """Ventana principal para la gestión de iconos del panel."""

    def __init__(self):
        super().__init__(title="Soplos Docklike")
        self.set_default_size(500, 550)
        
        # Verificar y crear configuración si no existe
        if not CONFIG_FILE:
            logger.warning(_("config_not_found"))
        
        # Establecer el icono de la ventana con el icono específico
        app_icon_path = os.path.join(ASSETS_DIR, ICON_FILE)
        if os.path.exists(app_icon_path):
            self.set_icon_from_file(app_icon_path)
        else:
            # Buscar el icono en rutas del sistema
            for icon_dir in ["/usr/share/icons/hicolor/128x128/apps", "/usr/share/pixmaps"]:
                system_icon = os.path.join(icon_dir, "soplos-docklike.png")
                if os.path.exists(system_icon):
                    self.set_icon_from_file(system_icon)
                    break
        
        try:
            if not os.path.exists(CONFIG_FILE):
                # Crear directorio si no existe
                os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
                # Crear archivo vacío con configuración inicial
                with open(CONFIG_FILE, 'w') as f:
                    f.write("pinned=;\n")
                logger.info(_("config_created").format(CONFIG_FILE))
        except Exception as e:
            logger.error(f"Error al crear archivo de configuración: {e}")
            self.show_error_dialog(
                "Error de Configuración",
                "No se pudo crear el archivo de configuración.\nEl programa funcionará con configuración temporal."
            )
        
        # Añadir grupo de aceleradores
        self.accel_group = Gtk.AccelGroup()
        self.add_accel_group(self.accel_group)
        
        # Contenedor principal con márgenes
        self.box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.box.set_margin_top(15)
        self.box.set_margin_bottom(15)
        self.box.set_margin_start(15)
        self.box.set_margin_end(15)
        self.add(self.box)
        
        # Cargar el logo de Soplos para la interfaz
        logo_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 
                                'assets/icons/soplos-logo.png')
        if os.path.exists(logo_path):
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                    filename=logo_path,
                    width=150,  # Ancho máximo del logo
                    height=150,  # Alto máximo del logo
                    preserve_aspect_ratio=True
                )
                logo_image = Gtk.Image.new_from_pixbuf(pixbuf)
                logo_image.set_margin_bottom(15)
                self.box.pack_start(logo_image, False, False, 0)
            except Exception as e:
                logger.warning(f"No se pudo cargar el logo: {e}")

        # Crear encabezado
        header = Gtk.Label()
        header.set_markup(f"<b>{_('header')}</b>")
        header.set_margin_bottom(10)
        self.box.pack_start(header, False, False, 0)

        # Crear ScrolledWindow para la lista
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_min_content_height(300)  # Establecer altura mínima
        self.box.pack_start(scrolled, True, True, 0)

        # Crear lista con iconos
        self.liststore = Gtk.ListStore(str, str, GdkPixbuf.Pixbuf, str)  # (nombre, ruta_icono, pixbuf, desktop_file)
        
        # Leer los iconos del archivo de configuración
        self.pinned_icons = []
        try:
            # Obtener las rutas de las aplicaciones
            app_paths = self.read_config_file()
            
            for desktop_file in app_paths:
                if os.path.exists(desktop_file):
                    icon_name, icon_path = get_icon_name_and_path(desktop_file)
                    app_name = get_app_name_from_desktop(desktop_file)
                    pixbuf = self.load_icon(icon_path)
                    if pixbuf:
                        self.liststore.append([app_name or icon_name, icon_path, pixbuf, desktop_file])
                else:
                    logger.warning(f"No se encontró el archivo: {desktop_file}")

        except Exception as e:
            logger.error(f"Error al leer archivo de configuración: {e}", exc_info=True)
            self.show_error_dialog("Error al leer la configuración", str(e))

        # Crear la vista de lista
        self.treeview = Gtk.TreeView(model=self.liststore)
        self.treeview.set_headers_visible(True)
        
        # Crear un renderer de imagen para los iconos
        renderer_pixbuf = Gtk.CellRendererPixbuf()
        column_icon = Gtk.TreeViewColumn(_("column_icon"), renderer_pixbuf, pixbuf=2)
        
        # Crear un renderer de texto para los nombres
        renderer_text = Gtk.CellRendererText()
        column_text = Gtk.TreeViewColumn(_("column_app"), renderer_text, text=0)
        column_text.set_expand(True)  # Permitir que la columna de texto se expanda
        
        # Agregar las columnas al TreeView
        self.treeview.append_column(column_icon)
        self.treeview.append_column(column_text)
        
        # Agregar la vista al ScrolledWindow
        scrolled.add(self.treeview)

        # Habilitar arrastrar y soltar
        self.treeview.enable_model_drag_source(
            start_button_mask=Gdk.ModifierType.BUTTON1_MASK,
            targets=[('text/plain', Gtk.TargetFlags.SAME_APP, 0)],
            actions=Gdk.DragAction.MOVE
        )
        self.treeview.enable_model_drag_dest(
            targets=[('text/plain', Gtk.TargetFlags.SAME_APP, 0)],
            actions=Gdk.DragAction.MOVE
        )
        self.treeview.connect('drag_data_get', self.on_drag_data_get)
        self.treeview.connect('drag_data_received', self.on_drag_data_received)

        # Botones de acción
        self.button_box = Gtk.Box(spacing=6)
        self.button_box.set_margin_top(10)
        self.button_box.set_margin_bottom(10)
        self.button_box.set_margin_start(10)
        self.button_box.set_margin_end(10)
        self.box.pack_start(self.button_box, False, False, 0)

        self.up_button = Gtk.Button(label=_('move_up'))    # '_S_ubir' -> 'S_ubir' (atajo: u)
        self.down_button = Gtk.Button(label=_('move_down')) # '_Bajar' (atajo: b)
        self.remove_button = Gtk.Button(label=_('remove'))
        
        # Habilitar el uso de mnemónicos
        self.up_button.set_use_underline(True)
        self.down_button.set_use_underline(True)
        self.remove_button.set_use_underline(True)

        self.button_box.pack_start(self.up_button, True, True, 0)
        self.button_box.pack_start(self.down_button, True, True, 0)
        self.button_box.pack_start(self.remove_button, True, True, 0)

        # Botón para añadir aplicaciones
        self.add_button = Gtk.Button(label=_('add_app'))
        self.add_button.set_use_underline(True)
        self.add_button.set_margin_start(10)
        self.add_button.set_margin_end(10)
        self.box.pack_start(self.add_button, False, False, 0)

        # Botones de guardar/cancelar
        self.action_box = Gtk.Box(spacing=6)
        self.action_box.set_margin_top(10)
        self.action_box.set_margin_bottom(10)
        self.action_box.set_margin_start(10)
        self.action_box.set_margin_end(10)
        self.box.pack_end(self.action_box, False, False, 0)

        # Botones de acción finales
        self.save_button = Gtk.Button(label=_('save'))
        self.quit_button = Gtk.Button(label=_('quit'))
        self.save_button.set_use_underline(True)
        self.quit_button.set_use_underline(True)
        self.action_box.pack_start(self.save_button, True, True, 0)
        self.action_box.pack_start(self.quit_button, True, True, 0)

        # Conectar los botones
        self.save_button.connect("clicked", self.on_save_clicked)
        self.quit_button.connect("clicked", self.on_quit_clicked)

        # Conectar botones
        self.up_button.connect("clicked", self.move_up)
        self.down_button.connect("clicked", self.move_down)
        self.remove_button.connect("clicked", self.remove_selected)
        self.add_button.connect("clicked", self.open_app_selector)
        
        # Añadir atajos de teclado después de crear los botones
        self.setup_keyboard_shortcuts()
        
        # Cambiar la gestión del evento delete-event
        # Eliminar cualquier uso de app.quit() o Gtk.main_quit()
        self.connect("delete-event", lambda w, e: False)  # Permitir que la ventana se cierre
        self.connect("destroy", lambda w: self.get_application().quit())

        # Asegurar que se establezca la clase de ventana correctamente
        # Esto es crítico para una correcta identificación por el gestor de ventanas
        if hasattr(self, 'set_wmclass'):
            self.set_wmclass("com.soplos.docklike", "com.soplos.docklike")
        
        # También establecemos la propiedad startup-id para una correcta integración
        # con el sistema de notificaciones de inicio
        screen = self.get_screen()
        if screen and hasattr(screen, 'get_display'):
            display = screen.get_display()
            if display and hasattr(display, 'get_startup_notification_id'):
                startup_id = GLib.getenv('GDK_STARTUP_ID')
                if startup_id:
                    if hasattr(display, 'notify_startup_complete'):
                        display.notify_startup_complete(startup_id)

    def setup_keyboard_shortcuts(self):
        """Configura los atajos de teclado"""
        # Ctrl+S para guardar
        self.save_button.add_accelerator("clicked", self.accel_group,
            ord('s'), Gdk.ModifierType.CONTROL_MASK, Gtk.AccelFlags.VISIBLE)
        
        # Ctrl+Q para salir
        self.quit_button.add_accelerator("clicked", self.accel_group,
            ord('q'), Gdk.ModifierType.CONTROL_MASK, Gtk.AccelFlags.VISIBLE)
        
        # Alt+U y Alt+↑ para subir
        self.up_button.add_accelerator("clicked", self.accel_group,
            ord('u'), Gdk.ModifierType.MOD1_MASK, Gtk.AccelFlags.VISIBLE)
        self.up_button.add_accelerator("clicked", self.accel_group,
            Gdk.KEY_Up, Gdk.ModifierType.MOD1_MASK, Gtk.AccelFlags.VISIBLE)
        
        # Alt+B y Alt+↓ para bajar
        self.down_button.add_accelerator("clicked", self.accel_group,
            ord('b'), Gdk.ModifierType.MOD1_MASK, Gtk.AccelFlags.VISIBLE)
        self.down_button.add_accelerator("clicked", self.accel_group,
            Gdk.KEY_Down, Gdk.ModifierType.MOD1_MASK, Gtk.AccelFlags.VISIBLE)
        
        # Delete para eliminar
        self.remove_button.add_accelerator("clicked", self.accel_group,
            Gdk.KEY_Delete, 0, Gtk.AccelFlags.VISIBLE)
        
        # Ctrl+A para añadir aplicación
        self.add_button.add_accelerator("clicked", self.accel_group,
            ord('a'), Gdk.ModifierType.CONTROL_MASK, Gtk.AccelFlags.VISIBLE)

    def load_icon(self, icon_path):
        """Carga el icono desde el path especificado y lo convierte en un Pixbuf"""
        try:
            if (icon_path and os.path.exists(icon_path)):
                return GdkPixbuf.Pixbuf.new_from_file_at_size(icon_path, 48, 48)
            
            # Icono por defecto
            default_icon = os.path.join(ASSETS_DIR, "application-default-icon.png")
            if os.path.exists(default_icon):
                return GdkPixbuf.Pixbuf.new_from_file_at_size(default_icon, 48, 48)
            
        except Exception as e:
            logger.error(f"Error al cargar icono: {e}")
        return None

    def move_up(self, widget):
        selection = self.treeview.get_selection()
        model, iter = selection.get_selected()
        if iter:
            row = model.get_path(iter)[0]
            if row > 0:
                prev_iter = model.get_iter(row - 1)
                model.swap(iter, prev_iter)
                self.treeview.set_cursor(model.get_path(iter))

    def move_down(self, widget):
        selection = self.treeview.get_selection()
        model, iter = selection.get_selected()
        if iter:
            row = model.get_path(iter)[0]
            if row < len(model) - 1:
                next_iter = model.get_iter(row + 1)
                model.swap(iter, next_iter)
                self.treeview.set_cursor(model.get_path(iter))

    def remove_selected(self, widget):
        selection = self.treeview.get_selection()
        model, iter = selection.get_selected()
        if iter:
            app_name = model.get_value(iter, 0)
            
            # Usar la traducción en lugar del texto hardcodeado
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.QUESTION,
                buttons=Gtk.ButtonsType.YES_NO,
                text=_('confirm_delete').format(app_name)
            )
            response = dialog.run()
            dialog.destroy()
            
            if response == Gtk.ResponseType.YES:
                model.remove(iter)

    def open_app_selector(self, widget):
        app_selector = AppSelectorDialog(self)
        response = app_selector.run()
        
        if response == Gtk.ResponseType.OK:
            selected_apps = app_selector.get_selected_apps()
            for app_path in selected_apps:
                # Verificar si la app ya está en la lista
                already_added = False
                for row in self.liststore:
                    if row[3] == app_path:
                        already_added = True
                        break
                
                if not already_added:
                    icon_name, icon_path = get_icon_name_and_path(app_path)
                    app_name = get_app_name_from_desktop(app_path)
                    pixbuf = self.load_icon(icon_path)
                    if pixbuf:
                        self.liststore.append([app_name or icon_name, icon_path, pixbuf, app_path])
                    else:
                        logger.warning(f"No se pudo cargar el icono para: {app_path}")
        
        app_selector.destroy()

    def restart_panel(self):
        """Reinicia el panel XFCE de forma simple y robusta"""
        try:
            import subprocess
            # Simplemente ejecutar el comando básico que sabemos que funciona
            subprocess.run(["xfce4-panel", "-r"], check=False)
            return True
        except Exception as e:
            logger.error(f"Error al reiniciar el panel: {e}")
            return False

    def on_save_clicked(self, button):
        """Guarda los cambios sin cerrar la ventana"""
        try:
            # Guardar la configuración
            if self.write_config_file(self.get_current_paths()):
                self.restart_panel()
                self.show_info_dialog("Completado", "Los cambios se han guardado correctamente")
            else:
                self.show_error_dialog("Error", "No se pudieron guardar los cambios")
            
        except Exception as e:
            self.show_error_dialog("Error al guardar", str(e))

    def get_current_paths(self):
        """Obtiene las rutas actuales de los archivos .desktop"""
        return [row[3] for row in self.liststore]

    def read_config_file(self):
        """Lee la configuración del archivo docklike-*.rc"""
        try:
            if not os.path.exists(CONFIG_FILE):
                return []
            
            with open(CONFIG_FILE, 'r') as f:
                content = f.read().strip()
                
            app_paths = []
            for line in content.splitlines():
                if line.startswith("pinned="):
                    # Obtener la lista de aplicaciones
                    paths = line.split('=')[1].strip().strip(';').split(';')
                    for path in paths:
                        if not path.strip():
                            continue
                            
                        # Si es una ruta completa y existe, usarla directamente
                        if os.path.exists(path.strip()):
                            app_paths.append(path.strip())
                        else:
                            # Si no es una ruta completa, buscar el archivo .desktop
                            app_id = os.path.splitext(os.path.basename(path))[0]
                            desktop_file = find_desktop_file(app_id)
                            if desktop_file:
                                app_paths.append(desktop_file)
                            else:
                                logger.warning(f"No se encontró el archivo: {app_id}")
                    break
            
            return app_paths
        except Exception as e:
            logger.error(_("error_reading_config").format(str(e)))
            return []

    def write_config_file(self, app_paths):
        """Escribe la configuración al archivo"""
        try:
            # Leer el contenido actual para preservar otras configuraciones
            current_config = []
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, 'r') as f:
                    current_config = f.readlines()

            # Convertir rutas completas a nombres de archivo si es posible
            pinned_items = []
            for path in app_paths:
                if os.path.exists(path):
                    app_id = os.path.splitext(os.path.basename(path))[0]
                    # Buscar el archivo en las ubicaciones estándar
                    for dir in ["/usr/share/applications", os.path.expanduser("~/.local/share/applications")]:
                        rel_path = os.path.join(dir, f"{app_id}.desktop")
                        if os.path.exists(rel_path):
                            pinned_items.append(rel_path)
                            break
                    else:
                        # Si no se encuentra en ubicaciones estándar, usar la ruta completa
                        pinned_items.append(path)

            # Generar la nueva línea de pinned
            pinned_line = f"pinned={';'.join(pinned_items)};\n"

            # Actualizar la configuración
            new_config = []
            pinned_updated = False
            
            for line in current_config:
                if line.startswith("pinned="):
                    new_config.append(pinned_line)
                    pinned_updated = True
                else:
                    new_config.append(line)
            
            if not pinned_updated:
                if not new_config or not new_config[0].startswith("[user]"):
                    new_config.insert(0, "[user]\n")
                new_config.append(pinned_line)

            # Guardar los cambios
            with open(CONFIG_FILE, 'w') as f:
                f.writelines(new_config)
            
            return True
        except Exception as e:
            logger.error(_("error_writing_config").format(str(e)))
            return False

    def show_error_dialog(self, title, message):
        """Muestra un diálogo de error"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=title
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()

    def show_info_dialog(self, title, message):
        """Muestra un diálogo informativo"""
        # Traducir mensajes comunes
        if title == "Completado":
            title = _('save_success')
        if message == "Los cambios se han guardado correctamente":
            message = _('save_success')
        
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=title
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()

    def on_quit_clicked(self, button):
        """Cierra la aplicación preguntando si hay cambios sin guardar"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_('confirm_quit')
        )
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            # Usar quit() del GtkApplication en lugar de Gtk.main_quit()
            self.get_application().quit()

    def close_window(self, widget):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_('confirm_quit')
        )
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            # También aquí usamos quit() del GtkApplication
            self.get_application().quit()

    def on_drag_data_get(self, treeview, drag_context, selection_data, info, time):
        """Obtiene los datos del elemento arrastrado"""
        model, iter = treeview.get_selection().get_selected()
        if iter:
            path = model.get_path(iter)
            selection_data.set_text(str(path), -1)

    def on_drag_data_received(self, treeview, drag_context, x, y, selection_data, info, time):
        """Recibe los datos del elemento arrastrado y lo mueve a la nueva posición"""
        model = treeview.get_model()
        drop_info = treeview.get_dest_row_at_pos(x, y)
        if drop_info:
            path, position = drop_info
            new_iter = model.get_iter(path)
            data = selection_data.get_text()
            old_path = Gtk.TreePath.new_from_string(data)
            old_iter = model.get_iter(old_path)
            model.move_before(old_iter, new_iter)
            treeview.set_cursor(path)