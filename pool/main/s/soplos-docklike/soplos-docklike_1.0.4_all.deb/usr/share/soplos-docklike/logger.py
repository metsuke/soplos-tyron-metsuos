import logging

# Configurar logging solo para warnings y errores
logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)