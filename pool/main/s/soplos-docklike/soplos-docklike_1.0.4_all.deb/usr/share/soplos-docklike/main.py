#!/usr/bin/env python3
import sys
import os
import shutil
import atexit
from pathlib import Path

def get_base_dir():
    """Obtiene el directorio base de la aplicación de forma segura"""
    try:
        # Intentar primero con __file__
        return os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # Si __file__ no está disponible, usar el directorio actual
        return os.path.dirname(os.path.abspath(sys.argv[0]))

def clean_pycache(base_dir=None):
    """Elimina todos los directorios __pycache__ de forma recursiva"""
    if base_dir is None:
        base_dir = get_base_dir()
    
    try:
        # Buscar y eliminar todos los __pycache__
        for root, dirs, files in os.walk(base_dir):
            if '__pycache__' in dirs:
                cache_dir = os.path.join(root, '__pycache__')
                try:
                    shutil.rmtree(cache_dir, ignore_errors=True)
                except Exception as e:
                    print(f"Error limpiando {cache_dir}: {e}")
    except Exception as e:
        print(f"Error en limpieza de cache: {e}")

# Obtener el directorio base una vez
BASE_DIR = get_base_dir()

# Limpiar al inicio
clean_pycache(BASE_DIR)

# Registrar limpieza al salir
atexit.register(clean_pycache, BASE_DIR)

# Ahora sí, el resto de imports y código
import glob
from config import logger
from translations.lang_utils import get_translation as _

# Desactivar warnings de PyGObject/DBus
import warnings
warnings.filterwarnings("ignore", category=Warning)

# Asegurar que podemos importar módulos locales
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

def check_docklike_plugin():
    """Verifica que el plugin Docklike esté instalado y activo"""
    # Verificar que el plugin docklike está activo 
    xfce_panel_dir = Path.home() / ".config/xfce4/panel"
    docklike_files = glob.glob(os.path.join(xfce_panel_dir, "docklike-*.rc"))
    
    if not docklike_files:
        # Buscar también en la configuración del panel
        panel_config = Path.home() / ".config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml"
        if panel_config.exists():
            try:
                if "docklike" in panel_config.read_text().lower():
                    return True
            except:
                pass
                
        print(_("plugin_not_active"))
        return False
    
    return True

def main():
    """Función principal de la aplicación."""
    # Ignorar mensajes de advertencia del bus de accesibilidad
    os.environ['NO_AT_BRIDGE'] = '1'
    
    # Verificar que el plugin está activo antes de continuar
    if not check_docklike_plugin():
        sys.exit(1)
        
    # Importar GTK y ejecutar la aplicación
    import gi
    gi.require_version('Gtk', '3.0')
    from gi.repository import Gtk, Gio, GdkPixbuf
    from gui.main_window import IconListWindow

    # Crear aplicación GTK
    app = Gtk.Application(
        application_id="com.soplos.docklike",
        flags=Gio.ApplicationFlags.FLAGS_NONE
    )

    def on_activate(app):
        win = IconListWindow()
        win.set_application(app)
        
        # Establecer el icono del programa para el sistema con el nombre correcto
        try:
            # Intentar cargar el icono por nombre desde el tema
            icon_theme = Gtk.IconTheme.get_default()
            icon = icon_theme.lookup_icon("com.soplos.docklike", 128, 0)
            if icon:
                win.set_icon(icon.load_icon())
            else:
                # Buscar el icono en rutas específicas
                for icon_dir in ["/usr/share/icons/hicolor/128x128/apps", 
                                "/usr/share/pixmaps", 
                                os.path.join(BASE_DIR, "assets/icons")]:
                    icon_path = os.path.join(icon_dir, "com.soplos.docklike.png")
                    if os.path.exists(icon_path):
                        win.set_icon_from_file(icon_path)
                        break
        except Exception as e:
            logger.warning(f"Error al cargar el icono de la aplicación: {e}")

        win.show_all()

    app.connect('activate', on_activate)
    
    # Usar run() en lugar de Gtk.main()
    return app.run(None)

if __name__ == "__main__":
    sys.exit(main())