from setuptools import setup, find_packages

setup(
    name="soplos-docklike",  # Correcto, no "soplos-dock-manager"
    version="1.0.4",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'PyGObject>=3.36.0',
        'pycairo>=1.16.0',
        'dbus-python>=1.2.16',
        'gettext>=0.20.0',
        'gir1.2-gtk-3.0>=3.24.0',
        'xfconf>=4.14.0',
        'dbus-x11',
    ],
    package_data={
        'soplos-docklike': [  # Correcto, no "soplos-dock-manager"
            'assets/*',
            'translations/*',
            'data/*.desktop',
        ],
    },
    data_files=[
        ('share/applications', ['data/com.soplos.docklike.desktop']),
    ],
    entry_points={
        'console_scripts': [
            'soplos-docklike=main:main',  # Correcto, no "soplos-dock-manager"
        ],
    },
    author="Sergi Perich",
    author_email="info@soploslinux.com",
    description="Soplos Docklike - Gestor de iconos para el dock de XFCE",  # Modificado
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    url="https://github.com/SoplosLinux/tyron",  # URL correcta
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: POSIX :: Linux",
    ],
    python_requires='>=3.6',
)
