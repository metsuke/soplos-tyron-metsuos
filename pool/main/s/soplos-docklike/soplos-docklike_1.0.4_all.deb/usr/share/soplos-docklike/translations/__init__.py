"""
Módulo de traducciones para Soplos Docklike
"""
from .lang_utils import get_translation

__all__ = ['get_translation']
