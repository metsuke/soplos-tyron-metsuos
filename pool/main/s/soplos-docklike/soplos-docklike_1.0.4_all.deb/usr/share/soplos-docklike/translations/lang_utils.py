import locale
import os
from .strings import TRANSLATIONS

def get_system_language():
    """Obtiene el código de idioma del sistema"""
    try:
        # Primera prioridad: variable de entorno LANG
        lang = os.getenv('LANGUAGE', '').split(':')[0] or \
               os.getenv('LANG', '').split('.')[0][:2].lower()
        if lang in TRANSLATIONS:
            return lang

        # Segunda prioridad: locale.getdefaultlocale()
        system_lang = locale.getdefaultlocale()[0]
        if system_lang:
            lang_code = system_lang.split('_')[0].lower()
            if lang_code in TRANSLATIONS:
                return lang_code

        # Tercera prioridad: locale.getlocale()
        current_locale = locale.getlocale()[0]
        if current_locale:
            lang_code = current_locale.split('_')[0].lower()
            if lang_code in TRANSLATIONS:
                return lang_code

    except Exception as e:
        print(f"Error detectando idioma: {e}")
    
    # Si no se encuentra el idioma o hay error, usar inglés por defecto
    return 'en'

def get_translation(key, default_text=None):
    """Obtiene la traducción para una clave en el idioma del sistema"""
    lang = get_system_language()
    
    try:
        # Intentar obtener la traducción en el idioma detectado
        if lang in TRANSLATIONS and key in TRANSLATIONS[lang]:
            return TRANSLATIONS[lang][key]
            
        # Si no existe en el idioma detectado, intentar en inglés
        if key in TRANSLATIONS['en']:
            return TRANSLATIONS['en'][key]
            
        # Si se proporcionó un texto por defecto, usarlo
        if default_text:
            return default_text
            
        # Si todo falla, devolver la clave
        return key
    except Exception as e:
        print(f"Error obteniendo traducción para {key}: {e}")
        return default_text if default_text else key