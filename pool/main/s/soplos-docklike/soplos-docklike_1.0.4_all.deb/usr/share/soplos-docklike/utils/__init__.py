"""
Módulo de utilidades para Docklike
"""