import os
import sys
import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gio

# Asegurar que podemos importar desde el directorio raíz
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

# Importación directa
from config import logger

def find_icon_in_system(icon_name):
    """Busca el icono en el sistema y devuelve su ruta"""
    if os.path.isabs(icon_name) and os.path.exists(icon_name):
        return icon_name

    icon_theme = Gtk.IconTheme.get_default()
    icon_info = icon_theme.lookup_icon(icon_name, 48, 0)
    if icon_info:
        return icon_info.get_filename()
    return None

def get_icon_name_from_desktop(desktop_file):
    """Obtiene el nombre del icono desde un archivo .desktop"""
    try:
        app_info = Gio.DesktopAppInfo.new_from_filename(desktop_file)
        if app_info:
            icon = app_info.get_icon()
            if icon:
                return icon.to_string()
    except Exception as e:
        logger.error(f"Error crítico: {e}")
    return None

def get_app_name_from_desktop(desktop_file):
    """Obtiene el nombre de la aplicación desde un archivo .desktop"""
    try:
        app_info = Gio.DesktopAppInfo.new_from_filename(desktop_file)
        if app_info:
            return app_info.get_name()
    except Exception as e:
        logger.debug(f"Error obteniendo nombre de aplicación: {e}")
    
    # Fallback: extraer del archivo
    try:
        with open(desktop_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.lower().startswith("name="):
                    return line.split('=')[1].strip()
    except Exception:
        pass
    
    # Usar el nombre del archivo si todo falla
    return os.path.basename(desktop_file).replace('.desktop', '')

def get_icon_name_and_path(desktop_file):
    """Obtiene el nombre del icono y su ruta desde un archivo .desktop"""
    if not desktop_file or not desktop_file.strip():
        return None, None

    icon_name = get_icon_name_from_desktop(desktop_file)
    icon_path = find_icon_in_system(icon_name) if icon_name else None
    return icon_name, icon_path