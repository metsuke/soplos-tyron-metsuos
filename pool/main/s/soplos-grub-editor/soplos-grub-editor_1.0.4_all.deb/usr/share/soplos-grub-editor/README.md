# Soplos GRUB Editor

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.4-green.svg)]()

Editor gráfico avanzado para la configuración de GRUB2, compatible con XFCE, Plasma y GNOME.

*Advanced graphical editor for GRUB2 configuration, compatible with XFCE, Plasma and GNOME.*

## 📝 Descripción

Una interfaz gráfica GTK3 para configurar y personalizar el gestor de arranque GRUB2: entradas, temas, fuentes, fondos, parámetros avanzados y más, con soporte completo de internacionalización.

## ✨ Características

- 🗂️ Edición visual de la configuración de GRUB2
- 🎨 Gestión e instalación de temas y fondos
- 🔤 Conversión e instalación de fuentes personalizadas
- 📝 Gestión de entradas de arranque personalizadas
- ⚙️ Configuración avanzada de parámetros del kernel
- 💾 Copias de seguridad y restauración automáticas
- 🌍 Internacionalización completa (8 idiomas)
- 🖥️ Compatible con XFCE, Plasma y GNOME
- 🌊 **Soporte completo para Wayland y X11**
- ⌨️ Atajos de teclado para todas las acciones

## 🛠️ Requisitos

- Python 3.8+
- GTK 3.0
- GRUB 2.x instalado
- Dependencias: PyGObject, pycairo, python-xlib, polib, python-dbus, Pillow

## 📥 Instalación

```bash
# Dependencias del sistema
sudo apt install python3-gi gir1.2-gtk-3.0 python3-gi-cairo grub2-common pkexec imagemagick python3-cairo python3-xlib python3-polib python3-dbus python3-pil

# Instalación Python
pip3 install -r requirements.txt

# Instalación manual
sudo python3 setup.py install

# Instalar archivos de escritorio e iconos
sudo cp assets/com.soplos.grubeditor.desktop /usr/share/applications/
sudo cp assets/icons/com.soplos.grubeditor.png /usr/share/icons/hicolor/128x128/apps/
sudo cp debian/com.soplos.grubeditor.metainfo.xml /usr/share/metainfo/
sudo update-desktop-database
sudo gtk-update-icon-cache /usr/share/icons/hicolor/
```

## 🚀 Uso

```bash
# Ejecutar la aplicación
soplos-grub-editor
```

La aplicación solicitará privilegios de administrador automáticamente usando `pkexec`.

## 🌊 Compatibilidad con Wayland

La aplicación es **totalmente compatible con Wayland** y funciona perfectamente en:

- **Plasma 6 + Wayland** (Soplos Linux Tyson)
- **GNOME + Wayland**
- **Sway** y otros compositores Wayland
- **X11** (todos los entornos tradicionales)

### Características específicas de Wayland:
- ✅ Detección automática del protocolo de ventanas
- ✅ Aplicación automática de temas (incluyendo tema oscuro en Plasma 6)
- ✅ Escalado correcto en monitores HiDPI
- ✅ Integración nativa con el compositor

### Resolución de problemas de temas:

Si la aplicación no usa el tema correcto:

```bash
# Forzar tema oscuro
GTK_THEME=Adwaita:dark soplos-grub-editor

# Forzar tema claro
GTK_THEME=Adwaita soplos-grub-editor

# Para Plasma con tema Breeze
GTK_THEME=Breeze-Dark soplos-grub-editor
```

## 🖥️ Características principales

- **General**: Timeout, entrada predeterminada, resolución, parámetros kernel, detección de otros SO
- **Apariencia**: Temas, fuentes, colores, fondos
- **Entradas**: Añadir, editar y gestionar entradas de arranque personalizadas
- **Seguridad**: Copias de seguridad automáticas antes de aplicar cambios
- **Validación**: Verificación de sintaxis y estructura antes de guardar

## 🌐 Idiomas soportados

- 🇪🇸 Español
- 🇺🇸 English
- 🇵🇹 Português
- 🇫🇷 Français
- 🇩🇪 Deutsch
- 🇮🇹 Italiano
- 🇷🇴 Română
- 🇷🇺 Русский

## 🐧 Compatibilidad con distribuciones

- ✅ **Soplos Linux Tyson** (Plasma 6 + Wayland)
- ✅ Ubuntu/Debian (GNOME/X11/Wayland)
- ✅ Fedora (GNOME/KDE/Wayland)
- ✅ Arch Linux (cualquier DE)
- ✅ openSUSE (KDE/GNOME)

## 📄 Licencia

Este proyecto está licenciado bajo [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Desarrolladores

Desarrollado por Sergi Perich

## 🔗 Enlaces

- [Página web](https://soploslinux.com)
- [Reportar problemas](https://github.com/SoplosLinux/tyron/issues)
- [Documentación](https://soploslinux.com/docs/soplos-grub-editor)

## 🆕 Novedades en la versión 1.0.4 (27 de julio de 2025)

- Cambio de icono del programa.

## 🆕 Novedades en la versión 1.0.3 (18 de julio de 2025)

- Actualización de metainfo para cumplir con AppStream/DEP-11.
- Renombrado de screenshots a screenshot1.png, screenshot2.png, etc.
- Mejoras menores de documentación y metadatos.
- Sin cambios funcionales en la aplicación.

## 🆕 Novedades en la versión 1.0.2 (15 de junio de 2025)

- Internacionalización completa (8 idiomas)
- Sistema de traducciones dinámico y robusto
- Mejoras en gestión de temas y fuentes
- Optimización de estructura y rendimiento

## 🆕 Novedades en la versión 1.0.1 (14 de junio de 2025)

- Mejoras en la conversión e instalación de fuentes
- Mejoras de estabilidad y corrección de errores

## 🆕 Novedades en la versión 1.0.0 (13 de junio de 2025)

- Lanzamiento inicial estable
- Gestión completa de configuración GRUB2
- Soporte para temas, fuentes y entradas personalizadas