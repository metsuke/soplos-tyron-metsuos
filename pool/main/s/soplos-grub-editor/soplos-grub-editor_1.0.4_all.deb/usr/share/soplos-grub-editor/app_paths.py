# Configuración general de la aplicación
APP_NAME = "Soplos GRUB Editor"
VERSION = "1.0.0"

# URLs del proyecto
PROJECT_URL = "https://github.com/SoplosLinux"
WEBSITE_URL = "https://soploslinux.com/"
CONTACT_EMAIL = "info@soploslinux.com"

# Configuración de rutas
import os
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ICON_PATH = os.path.join(BASE_DIR, 'assets', 'icons', 'com.soplos.grubeditor.png')
LOGO_PATH = os.path.join(BASE_DIR, 'assets', 'icons', 'soplos-logo.png')
