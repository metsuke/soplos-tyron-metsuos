# Este archivo está obsoleto y ha sido reemplazado por app_paths.py
# Se mantiene por compatibilidad, pero se recomienda actualizar todas las importaciones

import warnings
from translations.strings import _

warnings.warn(
    _('config_module_deprecated'), 
    DeprecationWarning, 
    stacklevel=2
)

from app_paths import *
