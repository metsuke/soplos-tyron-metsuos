"""
Módulos de configuración para el editor de GRUB
"""

from .grub_config import GrubConfig

__all__ = ['GrubConfig']