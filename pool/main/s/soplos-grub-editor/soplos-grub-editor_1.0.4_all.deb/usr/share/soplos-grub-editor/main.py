#!/usr/bin/env python3
import os
import sys
import subprocess
import logging
import shutil
import atexit
import gi

# Importar desde el directorio translations ANTES de configurar logging
from translations.strings import TRANSLATIONS
from app_paths import ICON_PATH, LOGO_PATH

# Obtener el idioma del sistema y configurar traducción ANTES de usar _()
def get_system_language():
    lang = os.environ.get('LANG', 'en_US.UTF-8')
    return lang.split('_')[0]

# Configurar el sistema de traducción ANTES de cualquier uso
LANG = get_system_language()
_ = lambda key: TRANSLATIONS.get(LANG, TRANSLATIONS['en']).get(key, TRANSLATIONS['en'][key])

# Definir las constantes de identificación de manera consistente
APP_ID = "com.soplos.grubeditor"
# Obtener WMCLASS del entorno si está definido (prioridad sobre definición interna)
WMCLASS = os.environ.get('WMCLASS', APP_ID)

# Configurar el registro de errores - cambiado a ERROR para producción
logging.basicConfig(
    level=logging.ERROR,
    format=_('log_levelname_message')
)

# Configuración para evitar conflictos con módulos estándar de Python
# Eliminar las rutas locales del path para priorizar módulos estándar
std_modules = ['locale', 'gettext']
for module in std_modules:
    if module in sys.modules:
        del sys.modules[module]

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GdkPixbuf, GLib, Gio, Gdk

# Establecer identificadores de aplicación globales
GLib.set_prgname(APP_ID)
# Verificar si el nombre de la aplicación ya está establecido para evitar llamadas múltiples
if GLib.get_application_name() != APP_ID:  # Corregido: Gtk.get_application_name() -> GLib.get_application_name()
    GLib.set_application_name(APP_ID)  # Usar APP_ID en lugar de nombre legible

# Establecer el icono predeterminado para todas las ventanas
try:
    Gtk.Window.set_default_icon_name("com.soplos.grubeditor")
except Exception as e:
    logging.warning(_('icon_set_error').format(e))

# Configuración para asegurar que GDK use el WMCLASS correcto
try:
    if hasattr(Gdk, 'set_program_class'):
        Gdk.set_program_class(WMCLASS)
except Exception as e:
    logging.warning(_('program_class_error').format(e))

# Importar módulos de la aplicación
from ui.main_window import GrubEditorWindow

def relanzar_como_root():
    """Relanza la aplicación con permisos de root usando pkexec con variables de entorno necesarias."""
    try:
        env = os.environ.copy()
        xdg_runtime_dir = f"/run/user/{os.getuid()}"
        display = env.get('DISPLAY', ':0')
        xauthority = env.get('XAUTHORITY', os.path.expanduser('~/.Xauthority'))
        
        cmd = [
            'pkexec',
            '--disable-internal-agent',
            'env', 
            f"DISPLAY={display}", 
            f"XAUTHORITY={xauthority}",
            f"XDG_RUNTIME_DIR={xdg_runtime_dir}",
            f"WMCLASS={APP_ID}",  # Pasar el WMCLASS correcto
            "HOME=/root",
            sys.executable,
            sys.argv[0]
        ]
        
        subprocess.run(cmd, check=True)
        sys.exit(0)
    except subprocess.CalledProcessError:
        logging.error(_('pkexec_error'))
        sys.exit(1)
    except Exception as e:
        logging.error(_('relaunch_error').format(str(e)))
        sys.exit(1)

def limpiar_pycache():
    """Limpia todos los directorios __pycache__ en el proyecto."""
    try:
        # Usar una ruta absoluta en lugar de __file__
        directorio_base = '/usr/local/bin/soplos-grub-editor'
        
        for raiz, dirs, archivos in os.walk(directorio_base):
            if '__pycache__' in dirs:
                ruta_cache = os.path.join(raiz, '__pycache__')
                try:
                    shutil.rmtree(ruta_cache)
                    logging.info(_('directory_cleaned').format(ruta_cache))
                except Exception as e:
                    logging.error(_('directory_clean_error').format(ruta_cache, str(e)))
    except Exception as e:
        logging.error(_('directory_clean_error').format('__pycache__', str(e)))

def main():
    """Función principal de la aplicación."""
    # Verificar si se está ejecutando como root
    if os.geteuid() != 0:
        relanzar_como_root()
        return
        
    # Ignorar mensajes de advertencia del bus de accesibilidad
    os.environ['NO_AT_BRIDGE'] = '1'
    
    # Crear aplicación GTK con el ID específico
    app = Gtk.Application(
        application_id=APP_ID,
        flags=Gio.ApplicationFlags.FLAGS_NONE
    )

    def on_activate(app):
        win = GrubEditorWindow()
        app.add_window(win)
        
        # Reemplazar el uso de set_wmclass (obsoleto) con una propiedad moderna
        # La propiedad role es más moderna que set_wmclass
        win.set_role(WMCLASS)
        
        # También podemos establecer el nombre de la clase para WM usando GDK
        screen = win.get_screen()
        if screen and hasattr(screen, 'get_display'):
            display = screen.get_display()
            if display and hasattr(display, 'set_startup_notification_id'):
                display.set_startup_notification_id(WMCLASS)
        
        # Establecer el icono del programa para el sistema - orden de prioridad:
        # 1. Por nombre (com.soplos.grubeditor)
        # 2. Por ruta absoluta en sistema (/usr/share/icons/...)
        # 3. Por ruta relativa (assets/icons/...)
        try:
            icon_theme = Gtk.IconTheme.get_default()
            try:
                icon = icon_theme.load_icon("com.soplos.grubeditor", 128, 0)
                win.set_icon(icon)
            except:
                # Fallback a la ruta absoluta si falla la carga por nombre
                icon_path = "/usr/share/icons/hicolor/128x128/apps/com.soplos.grubeditor.png"
                if os.path.exists(icon_path):
                    win.set_icon_from_file(icon_path)
                elif os.path.exists(ICON_PATH):
                    win.set_icon_from_file(ICON_PATH)
        except Exception as e:
            logging.error(f"Error al establecer icono: {e}")
        
        # Forzar actualización de propiedades de ventana antes de mostrar
        win.realize()
        
        # Ahora mostrar la ventana
        win.show_all()

    app.connect('activate', on_activate)
    return app.run(None)

if __name__ == "__main__":
    sys.exit(main())