"""
Módulos de interfaz de usuario para el editor de GRUB
"""

from .main_window import GrubEditorWindow
from .general_tab import GeneralTab
from .entries_tab import EntriesTab
from .appearance_tab import AppearanceTab

__all__ = [
    'GrubEditorWindow',
    'GeneralTab',
    'EntriesTab',
    'AppearanceTab'
]