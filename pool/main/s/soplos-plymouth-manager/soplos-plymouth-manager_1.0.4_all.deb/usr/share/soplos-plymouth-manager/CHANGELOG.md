# Changelog

Todos los cambios notables de este proyecto se documentarán en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es/1.0.0/),
y este proyecto se adhiere a [Semantic Versioning](https://semver.org/lang/es/).

## [1.0.4] - 2025-07-27

### 🎨 Cambiado
- Cambio de icono del programa.
- Desarrollador actualizado a Sergi Perich.

## [1.0.3] - 2025-07-18

### 🛠️ Mejorado - Metainfo y compatibilidad AppStream/DEP-11
- Actualización de metainfo para cumplir con AppStream/DEP-11.
- Renombrado de screenshots a screenshot1.png, screenshot2.png, etc.
- Mejoras menores de documentación y metadatos.
- Sin cambios funcionales en la aplicación.

## [1.0.0] - 2025-05-08

### 🎉 Lanzamiento Inicial
- Interfaz gráfica para gestionar temas Plymouth.
- Previsualización, instalación y aplicación de temas.
- Configuración avanzada.
- Soporte multiidioma (8 idiomas).
- Compatible con Soplos Linux y derivados.

---

## Tipos de Cambios

- **Añadido** para nuevas características
- **Cambiado** para cambios en funcionalidad existente
- **Obsoleto** para características que serán eliminadas
- **Eliminado** para características eliminadas
- **Corregido** para corrección de errores
- **Seguridad** para vulnerabilidades

## Contribuir

Para reportar errores o solicitar características:
- **Issues**: https://github.com/SoplosLinux/tyron/issues
- **Email**: info@soploslinux.com

## Soporte

- **Documentación**: https://soploslinux.com
- **Comunidad**: https://soploslinux.com/community
- **Support**: info@soploslinux.com
