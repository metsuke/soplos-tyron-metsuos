# Soplos Plymouth Manager

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.4-green.svg)]()

Gestor gráfico de temas Plymouth para Soplos Linux compatible con XFCE, Plasma y GNOME.

*Graphical Plymouth theme manager for Soplos Linux compatible with XFCE, Plasma and GNOME*

## 📝 Descripción

Una interfaz gráfica GTK3 para gestionar temas de arranque Plymouth: previsualización, instalación, aplicación y configuración avanzada de temas, con soporte multiidioma.

## ✨ Características

- 🎨 Previsualización de temas Plymouth
- 💾 Instalación y aplicación inmediata de temas
- ⚙️ Configuración avanzada
- 🌍 Soporte multiidioma (8 idiomas)
- 🖥️ Compatible con XFCE, Plasma y GNOME
- 🌊 **Soporte completo para Wayland y X11**
- 🎨 **Detección automática de temas del sistema**

## 🛠️ Requisitos

- Python 3.6+
- GTK 3.0
- Plymouth instalado

## 📥 Instalación

```bash
# Dependencias
sudo apt install python3-gi gir1.2-gtk-3.0 plymouth

# Instalación
sudo pip3 install .
```

## 🚀 Uso

```bash
# Ejecutar la aplicación
soplos-plymouth-manager
```

## 🌊 Compatibilidad con Wayland

La aplicación es **totalmente compatible con Wayland** y funciona perfectamente en:

- **Plasma 6 + Wayland** (Soplos Linux Tyson)
- **GNOME + Wayland**
- **Sway** y otros compositores Wayland
- **X11** (todos los entornos tradicionales)

### Características específicas de Wayland:
- ✅ Detección automática del protocolo de ventanas
- ✅ Aplicación automática de temas (incluyendo tema oscuro en Plasma 6)
- ✅ Escalado correcto en monitores HiDPI
- ✅ Integración nativa con el compositor

### Resolución de problemas de temas:

Si la aplicación no usa el tema correcto:

```bash
# Forzar tema oscuro
GTK_THEME=Adwaita:dark soplos-plymouth-manager

# Forzar tema claro
GTK_THEME=Adwaita soplos-plymouth-manager

# Para Plasma con tema Breeze
GTK_THEME=Breeze-Dark soplos-plymouth-manager
```

## 📸 Capturas de pantalla

### Lista de temas disponibles
![Lista de temas disponibles](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-plymouth-manager/screenshots/screenshot1.png)

### Previsualización del tema
![Previsualización del tema](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-plymouth-manager/screenshots/screenshot2.png)

### Configuración avanzada
![Configuración avanzada](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-plymouth-manager/screenshots/screenshot3.png)

## 🌐 Idiomas soportados

- 🇪🇸 Español
- 🇺🇸 English
- 🇵🇹 Português
- 🇫🇷 Français
- 🇩🇪 Deutsch
- 🇮🇹 Italiano
- 🇷🇴 Română
- 🇷🇺 Русский

## 🐧 Compatibilidad con distribuciones

- ✅ **Soplos Linux Tyson** (Plasma 6 + Wayland)
- ✅ Ubuntu/Debian (GNOME/X11/Wayland)
- ✅ Fedora (GNOME/KDE/Wayland)
- ✅ Arch Linux (cualquier DE)
- ✅ openSUSE (KDE/GNOME)

## 📄 Licencia

Este proyecto está licenciado bajo [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Desarrolladores

Desarrollado por Sergi Perich

## 🔗 Enlaces

- [Página web](https://soploslinux.com)
- [Reportar problemas](https://github.com/SoplosLinux/tyron/issues)
- [Ayuda](https://soploslinux.com)
- [Contacto](mailto:info@soploslinux.com)

## 📦 Versiones

### v1.0.4 (27/07/2025)
- Cambio de icono del programa.

### v1.0.3 (18/07/2025)
- Actualización de metainfo para cumplir con AppStream/DEP-11.
- Renombrado de screenshots a screenshot1.png, screenshot2.png, etc.
- Mejoras menores de documentación y metadatos.
- Sin cambios funcionales en la aplicación.

### v1.0.0 (08/05/2025)
- Versión inicial
