#!/usr/bin/env python3
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk
import os
import sys
import subprocess

class DebugWindow(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self, title="WM_CLASS Debug - Plymouth Manager")
        self.set_default_size(500, 400)
        
        # Datos del entorno
        env_wmclass = os.environ.get("WMCLASS", "No establecido")
        startup_id = os.environ.get("GDK_STARTUP_NOTIFICATION_ID", "No establecido")
        
        # Crear interfaz
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        self.add(box)
        
        # Etiquetas para información del sistema
        env_label = Gtk.Label(label=f"WMCLASS (env): {env_wmclass}")
        env_label.set_xalign(0)
        startup_label = Gtk.Label(label=f"GDK_STARTUP_NOTIFICATION_ID: {startup_id}")
        startup_label.set_xalign(0)
        app_id_label = Gtk.Label(label="AppID: com.soplos.plymouthmanager")
        app_id_label.set_xalign(0)
        
        # Botón para establecer WM_CLASS
        set_button = Gtk.Button(label="Establecer WM_CLASS")
        set_button.connect("clicked", self.set_wmclass_clicked)
        
        # Botón para mostrar información de la ventana actual
        check_button = Gtk.Button(label="Verificar WM_CLASS de esta ventana")
        check_button.connect("clicked", self.check_wmclass)
        
        # Área de texto para resultados
        self.result_text = Gtk.TextView()
        self.result_text.set_editable(False)
        scroll = Gtk.ScrolledWindow()
        scroll.set_hexpand(True)
        scroll.set_vexpand(True)
        scroll.add(self.result_text)
        
        # Agregar widgets al box
        box.pack_start(env_label, False, False, 0)
        box.pack_start(startup_label, False, False, 0)
        box.pack_start(app_id_label, False, False, 0)
        box.pack_start(set_button, False, False, 0)
        box.pack_start(check_button, False, False, 0)
        box.pack_start(scroll, True, True, 0)
        
        # Conectar señales
        self.connect("destroy", Gtk.main_quit)
    
    def set_wmclass_clicked(self, button):
        """Establecer WM_CLASS para esta ventana"""
        wmclass = "com.soplos.plymouthmanager"
        self.set_wmclass(wmclass, wmclass)
        buffer = self.result_text.get_buffer()
        buffer.set_text(f"WM_CLASS establecido a: {wmclass}")
        
    def check_wmclass(self, button):
        """Obtener información de WM_CLASS usando xprop"""
        try:
            # Forzar que la ventana se realice completamente
            self.realize()
            
            # Obtener información de WM_CLASS usando xprop
            window_id = self.get_window().get_xid()
            result = subprocess.run(
                ["xprop", "-id", str(window_id)], 
                capture_output=True, 
                text=True
            )
            
            # Actualizar el área de texto con los resultados
            buffer = self.result_text.get_buffer()
            buffer.set_text(result.stdout)
            
        except Exception as e:
            buffer = self.result_text.get_buffer()
            buffer.set_text(f"Error: {str(e)}")

if __name__ == "__main__":
    # Establecer variables de entorno para pruebas
    os.environ["WMCLASS"] = "com.soplos.plymouthmanager"
    
    # Configuración de GLib/Gtk
    import gi
    gi.require_version('Gtk', '3.0')
    from gi.repository import Gtk, GLib
    
    GLib.set_prgname("com.soplos.plymouthmanager")
    GLib.set_application_name("Soplos Plymouth Manager")
    
    # Crear y mostrar ventana
    window = DebugWindow()
    window.set_wmclass("com.soplos.plymouthmanager", "com.soplos.plymouthmanager")
    window.show_all()
    Gtk.main()
