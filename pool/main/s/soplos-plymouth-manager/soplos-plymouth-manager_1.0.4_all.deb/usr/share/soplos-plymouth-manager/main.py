#!/usr/bin/env python3
import os
import sys
import gi

# Definir las constantes de identificación de manera consistente
APP_ID = "com.soplos.plymouthmanager"
# Obtener WMCLASS del entorno si está definido (prioridad sobre definición interna)
WMCLASS = os.environ.get('WMCLASS', APP_ID)

# Deshabilitar mensajes de accesibilidad
os.environ['NO_AT_BRIDGE'] = '1'

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

# Establecer identificadores globales para GTK
GLib.set_prgname(APP_ID)
GLib.set_application_name(APP_ID)

# Establecer el icono predeterminado para todas las ventanas
try:
    Gtk.Window.set_default_icon_name(APP_ID)
except:
    pass

# Configuración para asegurar que GDK use el WMCLASS correcto
try:
    if hasattr(Gdk, 'set_program_class'):
        Gdk.set_program_class(WMCLASS)
except:
    pass

from src.app import PlymouthApp
from src.utils import show_error_dialog

def main():
    try:
        os.environ['GTK_CSD'] = '0'
        
        # Iniciar la aplicación usando las constantes definidas
        app = PlymouthApp()
        app.app_id = APP_ID
        app.wmclass = WMCLASS
        
        # Asegurar que la ventana principal establezca el WM_CLASS correctamente
        if hasattr(app, 'window') and isinstance(app.window, Gtk.Window):
            app.window.set_wmclass(WMCLASS, WMCLASS)
        
        app.run()
    except Exception as e:
        show_error_dialog(None, f"Error al iniciar la aplicación: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
