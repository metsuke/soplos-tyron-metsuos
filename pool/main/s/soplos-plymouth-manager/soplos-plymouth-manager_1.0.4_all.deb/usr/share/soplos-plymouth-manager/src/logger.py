import os
import logging
from datetime import datetime

LOG_DIR = os.path.expanduser("~/.local/share/soplos-plymouth-manager/logs")
LOG_FILE = os.path.join(LOG_DIR, f"plymouth-manager-{datetime.now().strftime('%Y%m%d')}.log")

def setup_logger():
    """Configura el sistema de registro"""
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    
    logger = logging.getLogger('PlymouthManager')
    logger.setLevel(logging.INFO)
    
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    
    # Handler para archivo
    fh = logging.FileHandler(LOG_FILE)
    fh.setLevel(logging.INFO)
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    
    # Handler para consola
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    
    return logger

logger = setup_logger()
