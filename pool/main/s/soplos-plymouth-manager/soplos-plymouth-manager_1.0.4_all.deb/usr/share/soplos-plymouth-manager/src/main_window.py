import gi
import os
import threading
import time
import subprocess

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, GdkPixbuf, Gdk, Gio

from .plymouth_manager import PlymouthManager
from .utils import show_error_dialog, show_info_dialog
from .constants import LOGO_PATH, ASSETS_DIR, APP_ICON, ICON_PATH, APPLICATION_ID
from .strings import get_string

class PlymouthSimulator(Gtk.Window):
    def __init__(self, theme_name):
        super().__init__(title=get_string('preview_of_theme').format(theme_name))
        self.theme_name = theme_name
        self.setup_ui()
        
    def setup_ui(self):
        """Configura la interfaz de simulación"""
        self.set_default_size(800, 600)
        self.set_position(Gtk.WindowPosition.CENTER)
        
        # Contenedor principal con fondo negro
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(box)
        
        # Fondo negro
        overlay = Gtk.Overlay()
        box.pack_start(overlay, True, True, 0)
        
        background = Gtk.EventBox()
        background.override_background_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(0, 0, 0, 1))
        overlay.add(background)
        
        # Contenedor para elementos de Plymouth
        preview_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        preview_box.set_halign(Gtk.Align.CENTER)
        preview_box.set_valign(Gtk.Align.CENTER)
        overlay.add_overlay(preview_box)
        
        # Imagen del tema
        preview_path = f"/usr/share/plymouth/themes/{self.theme_name}/preview.png"
        if os.path.exists(preview_path):
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                    preview_path,
                    400, 300,
                    True
                )
                image = Gtk.Image.new_from_pixbuf(pixbuf)
                preview_box.pack_start(image, False, False, 10)
            except:
                pass
        
        # Mensaje y barra de progreso
        message = Gtk.Label()
        message.set_markup(
            f'<span color="white" size="large">{get_string("previewing_theme").format(self.theme_name)}</span>'
        )
        preview_box.pack_start(message, False, False, 10)
        
        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_size_request(400, 10)
        self.progress_bar.set_margin_start(20)
        self.progress_bar.set_margin_end(20)
        preview_box.pack_start(self.progress_bar, False, False, 10)
        
        # Botón cerrar
        button = Gtk.Button.new_with_label(get_string('close'))
        button.connect("clicked", lambda w: self.destroy())
        button.set_halign(Gtk.Align.CENTER)
        button.set_margin_top(20)
        button.set_margin_bottom(20)
        box.pack_end(button, False, False, 0)

    def start_preview(self):
        """Inicia la simulación"""
        self.show_all()
        self.progress = 0
        GLib.timeout_add(50, self.update_progress)
        
    def update_progress(self):
        """Actualiza la barra de progreso"""
        if self.progress < 1.0:
            self.progress += 0.01
            self.progress_bar.set_fraction(self.progress)
            return True
        return False

class PlymouthThemeManager(Gtk.Window):
    def __init__(self, config):
        super().__init__(title=get_string('app_name'))
        self.config = config
        self.plymouth = PlymouthManager()
        
        # Intentar obtener APP_ID y WMCLASS desde el módulo principal
        try:
            from main import APP_ID, WMCLASS
            self.app_id = APP_ID
            self.wmclass = WMCLASS
        except ImportError:
            # Valores por defecto si no se puede importar
            self.app_id = APPLICATION_ID
            self.wmclass = self.app_id
        
        # Establecer el WM_CLASS primero, antes de cualquier otra operación
        self.set_wmclass(self.wmclass, self.wmclass)
        
        # Establecer el icono desde ICON_PATH 
        if os.path.exists(ICON_PATH):
            self.set_icon_from_file(ICON_PATH)
        else:
            # Intentar usar el icono por nombre
            self.set_icon_name(self.app_id)
        
        self.setup_ui()
        self.load_themes()
        GLib.idle_add(self.delayed_init)
        
        # Eliminar limpieza innecesaria al iniciar
        self.connect("destroy", self.on_destroy)

    def delayed_init(self):
        """Inicialización retrasada para asegurar que la ventana esté dibujada"""
        # Esperar un ciclo más del bucle de eventos
        GLib.timeout_add(100, self.show_current_theme)
        return False
    
    def setup_ui(self):
        """Configurar la interfaz de usuario"""
        # Contenedor principal con márgenes
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.add(main_box)
        
        # Encabezado
        header_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        header_box.set_margin_top(15)
        header_box.set_margin_bottom(15)
        header_box.set_margin_start(20)
        header_box.set_margin_end(20)
        main_box.pack_start(header_box, False, False, 0)
        
        # Título y descripción
        title_label = Gtk.Label()
        title_label.set_markup(f"<span size='large' weight='bold'>{get_string('app_name')}</span>")
        title_label.set_xalign(0.5)
        header_box.pack_start(title_label, False, False, 5)
        
        # Añadir el logo entre los textos
        if os.path.exists(LOGO_PATH):
            logo_image = Gtk.Image()
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                LOGO_PATH,
                width=64,    # Reducido de 128 a 64
                height=64,   # Reducido de 128 a 64
                preserve_aspect_ratio=True
            )
            logo_image.set_from_pixbuf(pixbuf)
            header_box.pack_start(logo_image, False, False, 5)  # Reducido el padding de 10 a 5
        
        desc_label = Gtk.Label(label=get_string('app_description'))
        desc_label.set_xalign(0.5)
        header_box.pack_start(desc_label, False, False, 5)
        
        # Contenedor para el contenido principal
        content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        content_box.set_margin_start(20)
        content_box.set_margin_end(20)
        content_box.set_margin_bottom(20)
        main_box.pack_start(content_box, True, True, 0)
        
        # Marco para la selección de tema
        theme_frame = Gtk.Frame(label=get_string('available_themes'))
        content_box.pack_start(theme_frame, True, True, 0)
        
        theme_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        theme_box.set_margin_top(10)
        theme_box.set_margin_bottom(10)
        theme_box.set_margin_start(10)
        theme_box.set_margin_end(10)
        theme_frame.add(theme_box)
        
        # Mensaje de estado
        self.status_label = Gtk.Label()
        self.status_label.set_xalign(0)
        theme_box.pack_start(self.status_label, False, False, 0)
        
        # Etiqueta para el tema actual
        self.current_theme_label = Gtk.Label()
        self.current_theme_label.set_xalign(0)
        theme_box.pack_start(self.current_theme_label, False, False, 0)
        
        # Desplegable para seleccionar el tema
        self.theme_combobox = Gtk.ComboBoxText()
        theme_box.pack_start(self.theme_combobox, False, False, 5)
        
        # Conectar la selección del combobox con la carga de la vista previa
        self.theme_combobox.connect("changed", self.on_theme_selected)
        
        # Área para la vista previa
        self.preview_image = Gtk.Image()
        # Ajustar el tamaño mínimo para evitar scroll
        self.preview_image.set_size_request(580, 200)
        preview_scrolled = Gtk.ScrolledWindow()
        preview_scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.NEVER)
        preview_scrolled.add(self.preview_image)
        theme_box.pack_start(preview_scrolled, True, True, 5)
        
        # Barra de progreso
        self.progress_frame = Gtk.Frame(label=get_string('progress_frame_title'))
        content_box.pack_start(self.progress_frame, False, False, 0)
        
        progress_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        progress_box.set_margin_top(10)
        progress_box.set_margin_bottom(10)
        progress_box.set_margin_start(10)
        progress_box.set_margin_end(10)
        self.progress_frame.add(progress_box)
        
        # Etiqueta de estado de la operación
        self.operation_label = Gtk.Label(label=get_string('applying_theme'))
        self.operation_label.set_xalign(0)
        progress_box.pack_start(self.operation_label, False, False, 0)
        
        # Barra de progreso
        self.progressbar = Gtk.ProgressBar()
        self.progressbar.set_show_text(True)
        self.progressbar.set_text(get_string('preparing'))
        progress_box.pack_start(self.progressbar, False, False, 0)
        
        # Detalles de la operación
        self.detail_label = Gtk.Label(label="")
        self.detail_label.set_xalign(0)
        self.detail_label.set_line_wrap(True)
        progress_box.pack_start(self.detail_label, False, False, 0)
        
        # Contenedor para botones - Cambiar a organización horizontal
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        button_box.set_margin_start(10)
        button_box.set_margin_end(10)
        content_box.pack_start(button_box, False, True, 0)

        # Botones con iconos y atajos
        buttons = [
            (get_string('button_apply_theme'), "preferences-desktop-theme", 
             get_string('tooltip_apply'), self.change_theme),
            (get_string('button_preview'), "view-preview", 
             get_string('tooltip_preview'), self.generate_preview),
            (get_string('button_install'), "document-open", 
             get_string('tooltip_install'), self.install_theme),
            (get_string('button_remove'), "edit-delete", 
             get_string('tooltip_remove'), self.remove_theme),
            (get_string('button_refresh'), "view-refresh", 
             get_string('tooltip_refresh'), self.refresh_themes),
            (get_string('button_exit'), "application-exit", 
             get_string('tooltip_exit'), self.close_app)
        ]

        # Crear tres columnas para los botones
        columns = [Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5) for _ in range(3)]
        for column in columns:
            column.set_homogeneous(True)  # Hacer que todos los botones tengan el mismo tamaño
            button_box.pack_start(column, True, True, 0)  # Expand y fill a True

        # Distribuir los botones en las columnas
        for i, (text, icon_name, tooltip, callback) in enumerate(buttons):
            button = Gtk.Button()
            button.set_size_request(-1, 40)  # Reducir altura del botón
            button.set_tooltip_text(tooltip)
            
            hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
            hbox.set_halign(Gtk.Align.CENTER)
            
            icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.SMALL_TOOLBAR)  # Icono más pequeño
            label = Gtk.Label(label=text, use_underline=True)
            label.set_line_wrap(True)  # Permitir wrap del texto
            label.set_line_wrap_mode(2)  # PANGO_WRAP_WORD
            label.set_max_width_chars(15)  # Limitar ancho del texto
            
            hbox.pack_start(icon, False, False, 0)
            hbox.pack_start(label, True, True, 0)
            
            button.add(hbox)
            button.connect("clicked", callback)
            
            # Añadir el botón a la columna correspondiente
            column_index = i % 3
            columns[column_index].pack_start(button, True, True, 0)

        # Atajos de teclado
        accel_group = Gtk.AccelGroup()
        self.add_accel_group(accel_group)

        # Definir atajos
        key_shortcuts = [
            (Gdk.KEY_a, self.change_theme),
            (Gdk.KEY_u, self.refresh_themes),
            (Gdk.KEY_q, self.close_app)
        ]

        # Añadir atajo Ctrl+T para cambiar tema
        key_shortcuts.append((Gdk.KEY_t, self.toggle_theme))

        for key, callback in key_shortcuts:
            accel_group.connect(
                key, 
                Gdk.ModifierType.CONTROL_MASK, 
                Gtk.AccelFlags.VISIBLE, 
                lambda *x: callback(None)
            )
        
        # Variable para controlar la cancelación de tareas
        self.cancel_operation = False
        
        # Conectar evento de cierre
        self.connect("destroy", Gtk.main_quit)
    
    def show_dependencies_warning(self):
        """Muestra un diálogo de advertencia sobre dependencias faltantes"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.OK,
            text=get_string('dependencies_missing')
        )
        
        message = get_string('dependencies_warning_message')
        
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    def show_current_theme(self):
        """Muestra el tema actualmente configurado en el sistema"""
        try:
            current_theme = self.plymouth.get_current_theme()
            if (current_theme):
                self.current_theme_label.set_markup(f"<b>{get_string('current_theme')}</b> {current_theme}")
                
                # Seleccionar el tema actual en el combobox
                model = self.theme_combobox.get_model()
                if (model):
                    for i in range(len(model)):
                        if model[i][0] == current_theme:
                            self.theme_combobox.set_active(i)
                            break
                
                # Cargar la vista previa del tema actual
                self.load_theme_preview(current_theme)
            else:
                self.current_theme_label.set_markup(
                    "<span foreground='orange'>⚠️ No se pudo determinar el tema actual. " 
                    "Verifica la configuración de Plymouth.</span>"
                )
        except Exception as e:
            self.logger.error(f"Error al mostrar tema actual: {e}")
            self.current_theme_label.set_markup(
                f"<span foreground='red'>⚠️ Error al obtener tema actual: {str(e)}</span>"
            )
    
    def load_themes(self):
        """Carga la lista de temas disponibles"""
        themes = self.plymouth.get_themes()
        if themes:
            # Crear nuevo modelo para evitar errores de GTK
            self.theme_combobox.get_model().clear()
            
            # Agregar los temas al combobox
            for theme in sorted(set(themes)):
                self.theme_combobox.append_text(theme)
            
            # Seleccionar el primer tema si no hay ninguno seleccionado
            if self.theme_combobox.get_active() == -1 and themes:
                self.theme_combobox.set_active(0)
                
            self.status_label.set_markup(f"<span foreground='green'>✓ {get_string('themes_loaded')}</span>")
        else:
            self.status_label.set_markup(f"<span foreground='red'>⚠️ {get_string('error_loading_themes')}</span>")
    
    def on_theme_selected(self, combobox):
        """Maneja la selección de un tema en el combobox"""
        # Asegurar que la interfaz está habilitada
        self.set_sensitive(True)
        
        theme_name = combobox.get_active_text()
        if theme_name and theme_name != getattr(self, '_last_selected_theme', None):
            # Limpiar procesos de Plymouth antes de cargar la vista previa
            self.plymouth.cleanup_plymouth()
            
            # Solo actualizar si no estamos suprimiendo las actualizaciones
            if not getattr(self, '_suppress_preview_updates', False):
                self._last_selected_theme = theme_name
                self.load_theme_preview(theme_name)
    
    def load_theme_preview(self, theme_name):
        """Carga la vista previa del tema seleccionado"""
        try:
            # Evitar recargas innecesarias si la imagen ya está cargada
            current_pixbuf = self.preview_image.get_pixbuf()
            if current_pixbuf:
                current_path = getattr(self, '_current_preview_path', None)
                preview_path = self.plymouth.get_theme_preview_path(theme_name)
                if current_path == preview_path:
                    return True

            # Obtener ruta de la vista previa
            preview_path = self.plymouth.get_theme_preview_path(theme_name)
            
            if not preview_path:
                self.preview_image.clear()
                self.preview_image.set_from_icon_name("image-missing", Gtk.IconSize.DIALOG)
                return False

            if os.path.exists(preview_path):
                try:
                    pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                        preview_path,
                        600, 400,
                        True
                    )
                    self.preview_image.set_from_pixbuf(pixbuf)
                    # Guardar la ruta actual para evitar recargas
                    self._current_preview_path = preview_path
                    return True
                except:
                    pass
            
            self.preview_image.clear()
            self.preview_image.set_from_icon_name("image-missing", Gtk.IconSize.DIALOG)
            return False
            
        except Exception as e:
            print(f"ERROR al cargar vista previa: {e}")
            self.preview_image.clear()
            self.preview_image.set_from_icon_name("image-missing", Gtk.IconSize.DIALOG)
            return False
    
    def refresh_themes(self, widget):
        """Actualiza la lista de temas"""
        self.load_themes()
        self.show_current_theme()
        self.show_info_dialog(get_string('list_updated'))  # Cambiado
    
    def update_progress_ui(self, fraction, text, detail_text):
        """Actualiza la UI de progreso desde el hilo principal"""
        self.progressbar.set_fraction(fraction)
        self.progressbar.set_text(text)
        self.detail_label.set_text(detail_text)
        
        # Esto es crítico: permitir que GTK procese otros eventos
        # durante la actualización de la interfaz
        while Gtk.events_pending():
            Gtk.main_iteration_do(False)
        
        return False  # Para uso con GLib.idle_add
    
    def update_progress(self, step, total_steps, message=""):
        """Actualiza la barra de progreso de forma segura desde cualquier hilo"""
        if self.cancel_operation:
            return
            
        fraction = step / total_steps
        percentage_text = f"{int(fraction * 100)}%"
        
        # Usar GLib.idle_add para enviar la actualización al hilo principal
        GLib.idle_add(
            self.update_progress_ui,
            fraction,
            percentage_text,
            message
        )
    
    def reset_progress_ui(self):
        """Reinicia la interfaz de progreso"""
        self.cancel_operation = False
        self.progressbar.set_fraction(0.0)
        self.progressbar.set_text("0%")
        self.detail_label.set_text("")
    
    def theme_installation_worker(self, theme_name, generate_preview=False):
        """Hilo de trabajo para la instalación del tema o generación de vista previa"""
        try:
            if self.cancel_operation:
                return

            # Etapa 1: Preparación
            self.update_progress(1, 10, get_string('progress_stage_1'))
            time.sleep(0.5)
            
            if self.cancel_operation:
                return
                
            # Etapa 2: Verificación del tema
            self.update_progress(2, 10, get_string('progress_stage_2'))
            time.sleep(0.5)
            
            if self.cancel_operation:
                return
                
            # Etapa 3: Obtener ruta del tema  
            self.update_progress(3, 10, get_string('progress_stage_3'))
            time.sleep(0.5)
            
            if self.cancel_operation:
                return
                
            # Etapa 4: Comprobar permisos
            self.update_progress(4, 10, get_string('progress_stage_4'))
            time.sleep(0.5)
            
            if self.cancel_operation:
                return
                
            # Etapa 5: Ejecutar el comando apropiado
            self.update_progress(5, 10, 
                get_string('progress_stage_5_preview') if generate_preview 
                else get_string('progress_stage_5_apply'))

            if generate_preview:
                preview_path = self.plymouth.generate_theme_preview(theme_name)
                if not preview_path:
                    GLib.idle_add(
                        self.installation_complete,
                        theme_name,
                        False,
                        "No se pudo generar la vista previa"
                    )
                    return

                # Forzar limpieza después de la captura
                self.plymouth.force_kill_plymouth()
                
                # Esperar a que los procesos terminen completamente
                time.sleep(1)
                
                # Actualizar la vista previa y reactivar la interfaz
                GLib.idle_add(self.preview_complete, theme_name)
            else:
                # Solo aplicar el tema si no estamos generando vista previa
                success, error_msg = self.plymouth.set_theme(theme_name)
                if not success:
                    GLib.idle_add(
                        self.installation_complete,
                        theme_name,
                        False,
                        f"Error: {error_msg}"
                    )
                    return
            
            # Etapa 6: Actualización de configuración
            self.update_progress(6, 10, get_string('progress_stage_6')) 
            time.sleep(0.3)
            
            if self.cancel_operation:
                return
                
            # Etapa 7: Actualización de initramfs  
            self.update_progress(7, 10, get_string('progress_stage_7'))
            time.sleep(0.3)
            
            if self.cancel_operation:
                return
                
            # Etapa 8: Aplicando cambios
            self.update_progress(8, 10, get_string('progress_stage_8'))
            time.sleep(0.3)
            
            if self.cancel_operation:
                return
                
            # Etapa 9: Verificación
            self.update_progress(9, 10, get_string('progress_stage_9')) 
            time.sleep(0.3)
            
            if self.cancel_operation:
                return
                
            # Etapa 10: Finalizado
            self.update_progress(10, 10, get_string('progress_stage_10'))
            time.sleep(0.5)
            
            # Notificar completado en el hilo principal
            GLib.idle_add(
                self.installation_complete,
                theme_name,
                True
            )
            
        except Exception as e:
            GLib.idle_add(
                self.installation_complete,
                theme_name,
                False,
                str(e)
            )
    
    def installation_complete(self, theme_name, success, error_msg=None):
        """Maneja la finalización de la instalación del tema"""
        # Ocultar barra de progreso
        self.progress_frame.hide()
        
        # Limpiar procesos de Plymouth
        self.plymouth.cleanup_plymouth()
        
        if success:
            self.show_info_dialog(get_string('theme_installed'))  # Cambiado
            # Reactivar actualizaciones de vista previa
            self._suppress_preview_updates = False
            self.show_current_theme()
        else:
            self.show_error_dialog(get_string('error_installing').format(error_msg))  # Cambiado
        
        # Habilitar la interfaz
        self.set_sensitive(True)
        
        # Reset the cancelation flag
        self.cancel_operation = False
        return False
    
    def cancel_current_operation(self):
        """Cancelar la operación actual"""
        self.cancel_operation = True
        self.detail_label.set_text("Cancelando operación...")
        
        # Esperar un poco y reiniciar la interfaz
        GLib.timeout_add(1000, self.reset_progress_ui)
        GLib.timeout_add(1000, self.set_sensitive, True)
    
    def change_theme(self, widget):
        """Cambia el tema de Plymouth"""
        theme_name = self.theme_combobox.get_active_text()
        
        if not theme_name:
            self.show_error_dialog(get_string('select_theme_first'))
            return
        
        # Mostrar diálogo de confirmación
        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=get_string('change_theme_question').format(theme_name)  # Cambiado
        )
        dialog.format_secondary_text(get_string('admin_privileges_required'))  # Cambiado
        response = dialog.run()
        dialog.destroy()
        
        if response != Gtk.ResponseType.YES:
            return
        
        # Deshabilitar temporalmente la actualización automática de la vista previa
        self._suppress_preview_updates = True
        
        # Preparar la interfaz para mostrar el progreso
        self.reset_progress_ui()
        self.operation_label.set_text(get_string('progress_operation_apply').format(theme_name))  # Cambiado
        self.progress_frame.show_all()
        
        # Iniciar hilo de trabajo
        worker_thread = threading.Thread(
            target=self.theme_installation_worker,
            args=(theme_name,)
        )
        worker_thread.daemon = True
        worker_thread.start()

    def generate_preview(self, widget):
        """Muestra una previsualización del tema seleccionado"""
        theme_name = self.theme_combobox.get_active_text()
        if not theme_name:
            self.show_error_dialog(get_string('select_theme_first'))
            return

        try:
            self.set_sensitive(False)
            self.reset_progress_ui()
            self.operation_label.set_text(get_string('progress_operation_preview').format(theme_name))
            self.progress_frame.show_all()
            
            self.plymouth.force_kill_plymouth()
            
            worker_thread = threading.Thread(
                target=self.theme_installation_worker,
                args=(theme_name, True)
            )
            worker_thread.daemon = True
            worker_thread.start()

        except Exception as e:
            self.show_error_dialog(get_string('error_preview').format(str(e)))
            self.set_sensitive(True)
            self.plymouth.force_kill_plymouth()

    def preview_complete(self, theme_name):
        """Maneja la finalización de la previsualización"""
        # Ocultar barra de progreso
        self.progress_frame.hide()
        
        # Actualizar la vista previa
        self.load_theme_preview(theme_name)
        
        # Reactivar la interfaz
        self.set_sensitive(True)
        
        # Limpiar bandera de cancelación
        self.cancel_operation = False
        
        return False

    def install_theme(self, widget):
        """Maneja la instalación de un nuevo tema"""
        dialog = Gtk.FileChooserDialog(
            title=get_string('select_theme_file'),
            parent=self,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            get_string('cancel'), Gtk.ResponseType.CANCEL,
            get_string('open'), Gtk.ResponseType.OK
        )
        
        filter_theme = Gtk.FileFilter()
        filter_theme.set_name(get_string('theme_files'))
        filter_theme.add_pattern("*.tar.gz")
        filter_theme.add_pattern("*.tgz")
        filter_theme.add_pattern("*.zip")
        dialog.add_filter(filter_theme)

        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            file_path = dialog.get_filename()
            dialog.destroy()
            
            # Mostrar diálogo de progreso
            progress_dialog = Gtk.MessageDialog(
                transient_for=self,
                modal=True,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.NONE,
                text=get_string('installing_theme_dialog')
            )
            progress_dialog.format_secondary_text(get_string('please_wait'))
            progress_dialog.show_all()
            
            while Gtk.events_pending():
                Gtk.main_iteration()
            
            success, message = self.plymouth.install_theme(file_path)
            
            progress_dialog.destroy()
            
            if success:
                self.show_info_dialog(get_string('theme_installed'))
                self.refresh_themes(None)
            else:
                self.show_error_dialog(get_string('error_installing').format(message))
        else:
            dialog.destroy()

    def remove_theme(self, widget):
        """Maneja la eliminación de un tema"""
        theme_name = self.theme_combobox.get_active_text()
        if not theme_name:
            self.show_error_dialog(get_string('select_theme_first'))
            return

        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=get_string('remove_theme_question')
        )
        dialog.format_secondary_text(get_string('remove_theme_confirm').format(theme_name))

        response = dialog.run()
        dialog.destroy()

        if response == Gtk.ResponseType.YES:
            success, message = self.plymouth.remove_theme(theme_name)
            if success:
                self.show_info_dialog(get_string('theme_deleted'))
                self.refresh_themes(None)
            else:
                self.show_error_dialog(get_string('error_deleting').format(message))

    def show_error_dialog(self, message):
        """Muestra un diálogo de error"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=get_string('error')
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    def show_info_dialog(self, message):
        """Muestra un diálogo informativo"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=get_string('information')
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    def close_app(self, widget):
        """Cierra la aplicación preguntando antes"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=get_string('confirm_exit')
        )
        dialog.format_secondary_text(get_string('confirm_exit_message'))
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            self.destroy()
            Gtk.main_quit()

    def on_destroy(self, widget):
        """Manejador del evento destroy"""
        # No hacer nada aquí, ya que el cierre se maneja en close_app
        pass

    def toggle_theme(self, widget):
        """Cambia entre tema claro y oscuro"""
        if hasattr(self, 'app'):
            self.app.toggle_theme()

class SoplosPlymouthManager(Gtk.Application):
    def __init__(self):
        # Asegurar que tengamos un ID de aplicación único
        self.app_id = "com.soplos.plymouthmanager"
        
        # Establecer nombre del programa
        GLib.set_application_name("Soplos Plymouth Manager")
        GLib.set_prgname(self.app_id)
        
        super().__init__(
            application_id=self.app_id,
            flags=Gio.ApplicationFlags.FLAGS_NONE
        )
        
        self.window = None

    def do_activate(self):
        if not self.window:
            self.window = Gtk.ApplicationWindow(application=self)
            # Establecer WM_CLASS específicamente
            self.window.set_wmclass("com.soplos.plymouthmanager", "com.soplos.plymouthmanager")