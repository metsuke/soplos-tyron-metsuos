# Changelog

Todos los cambios notables de este proyecto serán documentados en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es/1.0.0/),
y este proyecto adhiere al [Semantic Versioning](https://semver.org/lang/es/).

## [1.0.4] - 2025-07-27

### Cambiado
- Cambio de icono del programa.
- El desarrollador es ahora Sergi Perich.

## [1.0.3] - 2025-07-18

### Cambiado
- Actualización de metainfo para cumplir con AppStream/DEP-11.
- Mejoras menores en la integración y documentación.
- Sin cambios funcionales en la aplicación.

## [1.0.2] - 2025-06-17

### Añadido
- Soporte para formatos de fecha y hora específicos de cada región
- Opción para restablecer manualmente las traducciones a los valores predeterminados

### Mejorado
- Optimizaciones en el rendimiento de la interfaz gráfica
- Mejoras en la gestión de errores y mensajes al usuario
- Actualización de dependencias a versiones más recientes

### Corregido
- Problemas menores de localización en idiomas existentes
- Errores tipográficos y de formato en las traducciones
- Fallos raros en la detección automática del idioma

## [1.0.1] - 2025-01-15

### Añadido
- Sistema completo de internacionalización (i18n) con soporte para 8 idiomas
- Traducciones completas para Español, Inglés, Francés, Portugués, Alemán, Italiano, Ruso y Rumano
- Diálogo de búsqueda de repositorios más rápidos completamente traducido
- Plantillas de distribución (Debian Stable, Testing/Trixie, Sid/Unstable, Soplos Linux Tyron)
- Detección automática del idioma del sistema
- Sistema de gestión de traducciones robusto y extensible

### Mejorado
- Interfaz completamente localizada en todos los componentes
- Mejoras en la experiencia de usuario con textos más claros
- Sistema de fallback para traducciones faltantes
- Consistencia en el uso de mnemonics y atajos de teclado

### Corregido
- Problemas de codificación de caracteres en diferentes idiomas
- Mejoras en la detección del locale del sistema
- Correcciones menores en la interfaz gráfica

## [1.0.0] - 2025-05-08

### Añadido
- Interfaz gráfica completa desarrollada con GTK3 y Adwaita
- Gestión segura de repositorios con autenticación PolicyKit
- Funcionalidad para habilitar/deshabilitar repositorios de APT
- Actualización automática de caché de paquetes tras cambios
- Sistema de logging y manejo de errores robusto
- Soporte para internacionalización (i18n)
- Interfaz responsiva que se adapta al tamaño de ventana
- Validación de permisos y estado del sistema
- Empaquetado completo para distribuciones Debian/Ubuntu
- Archivo .desktop para integración con el menú de aplicaciones
- Documentación completa y metadatos del proyecto
- Sistema de limpieza automática de archivos de caché Python
- Manejo elegante de señales del sistema (SIGINT, SIGTERM)
- Configuración automática del entorno de ejecución

[1.0.4]: https://github.com/SoplosLinux/tyron/releases/tag/soplos-repo-selector-v1.0.4
[1.0.3]: https://github.com/SoplosLinux/tyron/releases/tag/soplos-repo-selector-v1.0.3
[1.0.2]: https://github.com/SoplosLinux/tyron/releases/tag/soplos-repo-selector-v1.0.2
[1.0.1]: https://github.com/SoplosLinux/tyron/releases/tag/soplos-repo-selector-v1.0.1
[1.0.0]: https://github.com/SoplosLinux/tyron/releases/tag/soplos-repo-selector-v1.0.0
