#!/usr/bin/env python3
"""
Script de configuración para Soplos Repository Selector
"""
from setuptools import setup, find_packages
import os

# Leer el archivo README para la descripción larga
def read_readme():
    try:
        with open('README.md', 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        return "Gestor de repositorios para Soplos Linux con soporte multiidioma"

setup(
    name="soplos-repo-selector",
    version="1.0.4",
    author="Sergi Perich",
    author_email="info@soploslinux.com",
    description="Gestor de repositorios para Soplos Linux con soporte multiidioma",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://soploslinux.com",
    project_urls={
        "Bug Reports": "https://github.com/SoplosLinux/tyron/issues",
        "Source": "https://github.com/SoplosLinux/tyron",
        "Documentation": "https://soploslinux.com",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: System Administrators",
        "Intended Audience :: End Users/Desktop",
        "Topic :: System :: Systems Administration",
        "Topic :: System :: Software Distribution",
        "License :: OSI Approved :: GNU General Public License v3 or later (GPLv3+)",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: POSIX :: Linux",
        "Environment :: X11 Applications :: GTK",
        "Natural Language :: Spanish",
        "Natural Language :: English",
        "Natural Language :: French",
        "Natural Language :: Portuguese",
        "Natural Language :: German",
        "Natural Language :: Italian",
        "Natural Language :: Russian",
        "Natural Language :: Romanian",
    ],
    python_requires=">=3.7",
    install_requires=[
        "pygobject>=3.20.0",
        "requests>=2.20.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "flake8>=3.8.0",
            "black>=21.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "soplos-repo-selector=main:main",
        ],
    },
    data_files=[
        ("share/applications", ["assets/com.soplos.reposelector.desktop"]),
        ("share/metainfo", ["debian/com.soplos.reposelector.metainfo.xml"]),
        ("share/icons/hicolor/scalable/apps", ["assets/icons/com.soplos.reposelector.svg"]),
        ("share/icons/hicolor/128x128/apps", ["assets/icons/com.soplos.reposelector.png"]),
    ],
    include_package_data=True,
    package_data={
        "src": ["i18n/translations/*.py"],
        "assets": ["icons/*", "*.desktop"],
    },
    zip_safe=False,
    keywords="repository apt debian soplos linux multilingual i18n",
)
