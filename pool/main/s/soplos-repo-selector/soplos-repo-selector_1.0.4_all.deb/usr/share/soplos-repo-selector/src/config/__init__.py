"""
Módulo de configuración para Soplos Repo Selector
"""

from src.config.constants import *
