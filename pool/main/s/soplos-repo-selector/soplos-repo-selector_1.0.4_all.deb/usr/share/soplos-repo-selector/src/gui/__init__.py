"""
Módulo de interfaz gráfica para Soplos Repo Selector
"""
