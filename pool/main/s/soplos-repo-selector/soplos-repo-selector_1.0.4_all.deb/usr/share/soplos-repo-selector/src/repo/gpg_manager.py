import os
import subprocess
import tempfile
from pathlib import Path
from src.utils.error_handler import log_info, log_error, log_warning
from src.i18n.strings import get_string

class GPGManager:
    """
    Administrador de claves GPG para repositorios.
    Utiliza métodos modernos en lugar de apt-key (obsoleto).
    """
    
    def __init__(self):
        # Directorios estándar para claves GPG
        self.keyrings_dir = '/usr/share/keyrings'
        self.etc_keyrings_dir = '/etc/apt/keyrings'
        
        # Asegurar que el directorio etc_keyrings_dir existe (prioridad)
        self._ensure_keyrings_dir()
    
    def _ensure_keyrings_dir(self):
        """Asegura que el directorio de keyrings existe"""
        # Preferimos /etc/apt/keyrings (nuevo estándar)
        if not os.path.exists(self.etc_keyrings_dir):
            try:
                # Intentar crear el directorio con sudo
                subprocess.run(['sudo', 'mkdir', '-p', self.etc_keyrings_dir], 
                               check=True, capture_output=True)
                log_info(f"Directorio creado: {self.etc_keyrings_dir}")
            except subprocess.CalledProcessError as e:
                log_warning(f"No se pudo crear {self.etc_keyrings_dir}: {e}")
    
    def get_all_keys(self):
        """Obtiene todas las claves GPG disponibles"""
        keys = []
        
        # Revisar ambos directorios
        for keyring_dir in [self.keyrings_dir, self.etc_keyrings_dir]:
            if os.path.exists(keyring_dir):
                for file in os.listdir(keyring_dir):
                    if file.endswith(('.gpg', '.asc', '.pgp')):
                        key_path = os.path.join(keyring_dir, file)
                        key_info = self._get_key_info(key_path)
                        keys.append(key_info)
        
        return keys
    
    def _get_key_info(self, key_path):
        """Obtiene información de una clave GPG"""
        info = {
            'name': os.path.basename(key_path),
            'path': key_path,
            'format': 'ASCII' if key_path.endswith('.asc') else 'Binario GPG',
            'description': 'Clave GPG'
        }
        
        try:
            # Intentar obtener más información con gpg
            result = subprocess.run(
                ["gpg", "--show-keys", "--with-colons", key_path],
                check=False, capture_output=True, text=True, timeout=2
            )
            
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    parts = line.split(':')
                    if len(parts) > 9:
                        if parts[0] == "uid":
                            # Extraer nombre/email
                            info['description'] = parts[9]
                            break
                        elif parts[0] == "pub" and len(parts) > 4:
                            # Al menos obtener ID de clave
                            info['description'] = f"ID: {parts[4]}"
        except Exception as e:
            log_warning(f"Error al obtener información de la clave {key_path}: {e}")
        
        return info
    
    def import_key_from_file(self, source_path, key_name=None):
        """
        Importa una clave GPG desde un archivo
        
        Args:
            source_path: Ruta al archivo de clave
            key_name: Nombre para guardar la clave (opcional)
            
        Returns:
            tuple: (éxito, mensaje o ruta)
        """
        try:
            if not os.path.exists(source_path):
                return False, f"El archivo {source_path} no existe"
            
            # Si no se proporciona nombre, usar el nombre del archivo
            if not key_name:
                key_name = os.path.basename(source_path)
            
            # Asegurar que el nombre termina en .gpg
            if not key_name.endswith(('.gpg', '.asc', '.pgp')):
                key_name += '.gpg'
            
            # Determinar directorio de destino
            dst_dir = self.etc_keyrings_dir if os.path.exists(self.etc_keyrings_dir) else self.keyrings_dir
            dst_path = os.path.join(dst_dir, key_name)
            
            # Verificar si la clave es ASCII y necesita conversión
            is_ascii = self._is_ascii_armored(source_path)
            
            if is_ascii:
                # Si es ASCII, convertir a formato binario GPG
                command = f"cat '{source_path}' | gpg --dearmor > '{dst_path}'"
                result = subprocess.run(['sudo', 'bash', '-c', command], 
                                      check=True, capture_output=True)
            else:
                # Si ya es binaria, solo copiar
                result = subprocess.run(['sudo', 'cp', source_path, dst_path], 
                                      check=True, capture_output=True)
            
            # Establecer permisos correctos
            subprocess.run(['sudo', 'chmod', '644', dst_path], check=True, capture_output=True)
            
            return True, dst_path
            
        except subprocess.CalledProcessError as e:
            error_msg = e.stderr.decode() if hasattr(e, 'stderr') else str(e)
            log_error(f"Error al importar clave: {error_msg}")
            return False, error_msg
        except Exception as e:
            log_error(f"Error inesperado al importar clave: {e}")
            return False, str(e)
    
    def download_key(self, url, key_name=None):
        """
        Descarga e importa una clave GPG desde una URL
        
        Args:
            url: URL de la clave
            key_name: Nombre para guardar la clave (opcional)
            
        Returns:
            tuple: (éxito, mensaje o ruta)
        """
        try:
            # Generar nombre si no se proporciona
            if not key_name:
                import hashlib
                key_name = hashlib.md5(url.encode()).hexdigest() + '.gpg'
            elif not key_name.endswith(('.gpg', '.asc', '.pgp')):
                key_name += '.gpg'
            
            # Determinar directorio de destino
            dst_dir = self.etc_keyrings_dir if os.path.exists(self.etc_keyrings_dir) else self.keyrings_dir
            dst_path = os.path.join(dst_dir, key_name)
            
            # Descargar y procesar la clave
            command = f"curl -fsSL '{url}' | gpg --dearmor > '{dst_path}'"
            result = subprocess.run(['sudo', 'bash', '-c', command], 
                                  check=True, capture_output=True)
            
            # Establecer permisos correctos
            subprocess.run(['sudo', 'chmod', '644', dst_path], check=True, capture_output=True)
            
            return True, dst_path
            
        except subprocess.CalledProcessError as e:
            error_msg = e.stderr.decode() if hasattr(e, 'stderr') else str(e)
            log_error(f"Error al descargar clave: {error_msg}")
            return False, error_msg
        except Exception as e:
            log_error(f"Error inesperado al descargar clave: {e}")
            return False, str(e)
    
    def _is_ascii_armored(self, file_path):
        """Verifica si un archivo es una clave GPG en formato ASCII armored"""
        try:
            # Leer los primeros 100 bytes del archivo
            with open(file_path, 'rb') as f:
                header = f.read(100).decode('utf-8', errors='ignore')
            
            # Las claves ASCII normalmente comienzan con "-----BEGIN PGP"
            return "-----BEGIN PGP" in header
        except:
            return False
    
    def verify_key(self, key_path):
        """
        Verifica si una clave GPG es válida
        
        Args:
            key_path: Ruta a la clave
            
        Returns:
            bool: True si es válida, False en caso contrario
        """
        try:
            # Verificar si el archivo existe
            if not os.path.exists(key_path):
                return False
            
            # Intentar obtener información con gpg
            result = subprocess.run(
                ["gpg", "--show-keys", key_path],
                check=False, capture_output=True
            )
            
            return result.returncode == 0
            
        except Exception:
            return False
