"""
Módulo para gestionar los repositorios APT en el sistema
"""

import os
import re
import subprocess
from typing import List, Dict, Any, Optional, Union, Tuple
import tempfile
from pathlib import Path
from src.repo.repo_file_manager import RepoFileManager

class RepoManager:
    """
    Gestiona los repositorios APT del sistema.
    
    Esta clase proporciona métodos para leer, añadir, editar y eliminar repositorios.
    """
    
    def __init__(self):
        # Rutas de archivos de repositorio
        self.sources_dir = '/etc/apt/sources.list.d'
        self.main_sources = '/etc/apt/sources.list'
        self.repo_cache = None
        self.cache_valid = False
        
        # Determinar si se puede usar el formato moderno (deb822)
        self.use_modern_format = self._check_modern_format_support()
        self.file_manager = RepoFileManager()
    
    def _check_modern_format_support(self) -> bool:
        """Comprueba si el sistema soporta el formato moderno de repositorios (deb822)"""
        try:
            # Verificar versión de APT que soporta formato deb822
            result = subprocess.run(['apt', '--version'], capture_output=True, text=True)
            if result.returncode == 0:
                version_match = re.search(r'apt\s+(\d+)\.(\d+)', result.stdout)
                if version_match:
                    major = int(version_match.group(1))
                    minor = int(version_match.group(2))
                    # Formato deb822 está disponible desde apt 1.1
                    return major > 1 or (major == 1 and minor >= 1)
            return False
        except Exception:
            return False
    
    def get_all_repos(self, use_cache=True) -> List[Dict[str, Any]]:
        """
        Obtiene todos los repositorios definidos en el sistema.
        
        Args:
            use_cache: Si es True, usa los resultados en caché si están disponibles
            
        Returns:
            Lista de diccionarios, cada uno representando un repositorio
        """
        # IMPORTANTE: NO USAR CACHÉ cuando se esté en operación de eliminación/aplicación
        # Esta es la causa raíz del problema donde se muestran repos eliminados
        if not use_cache or self.cache_valid == False or self.repo_cache is None:
            # Forzar invalidación de caché
            self.cache_valid = False
            self.repo_cache = None
            
            repos = []
            
            # Procesar el archivo sources.list principal
            if os.path.exists(self.main_sources):
                repos.extend(self.file_manager.read_sources_file(self.main_sources))
            
            # Procesar archivos en sources.list.d
            if os.path.exists(self.sources_dir):
                for filename in os.listdir(self.sources_dir):
                    filepath = os.path.join(self.sources_dir, filename)
                    if not os.path.isfile(filepath):
                        continue
                    repos.extend(self.file_manager.read_sources_file(filepath))
            
            # Guardar en caché
            self.repo_cache = repos
            self.cache_valid = True
            
            return repos
        else:
            # Usar caché existente
            return self.repo_cache
    
    def invalidate_cache(self):
        """Invalida la caché de repositorios"""
        self.cache_valid = False
        self.repo_cache = None
    
    def clear_all_repos(self, target=None):
        """
        Elimina todos los repositorios actuales o los especificados
        
        Args:
            target: Opcional. Si se especifica, solo elimina esos repositorios
        """
        # Forzar invalidación de caché después de eliminar
        self.invalidate_cache()

    def create_missing_dirs(self):
        """
        Crea los directorios necesarios para almacenar repositorios si no existen
        """
        os.makedirs(self.sources_dir, exist_ok=True)

    def is_valid_repo_uri(self, uri: str) -> bool:
        """
        Verifica si un URI de repositorio es válido
        
        Args:
            uri: URI a verificar
            
        Returns:
            True si es válido, False en caso contrario
        """
        # Patrones válidos para URIs de repositorio
        patterns = [
            # HTTP/HTTPS
            r'^https?://[\w\.-]+(?::\d+)?(?:/[\w\.-]+)*/?$',
            # FTP
            r'^ftp://[\w\.-]+(?::\d+)?(?:/[\w\.-]+)*/?$',
            # File
            r'^file:/(?:/[\w\.-]+)+/?$',
            # CD-ROM
            r'^cdrom:\[[\w\s\.-]+\]/?(?:/[\w\.-]+)*/?$'
        ]
        
        return any(re.match(pattern, uri) for pattern in patterns)
    
    def get_repo_info(self, uri: str) -> Dict[str, Any]:
        """Obtiene información detallada de un repositorio"""
        info = {
            'uri': uri,
            'reachable': False,
            'response_time': None,
            'last_modified': None,
            'content_length': None
        }
        
        try:
            import urllib.request
            import time
            from urllib.parse import urljoin
            
            # Probar conectividad
            start_time = time.time()
            
            # Intentar acceder a Release o InRelease
            for release_file in ['InRelease', 'Release']:
                try:
                    release_url = urljoin(uri.rstrip('/') + '/', 'dists/stable/' + release_file)
                    with urllib.request.urlopen(release_url, timeout=10) as response:
                        info['reachable'] = True
                        info['response_time'] = time.time() - start_time
                        info['last_modified'] = response.headers.get('Last-Modified')
                        info['content_length'] = response.headers.get('Content-Length')
                        break
                except:
                    continue
                    
        except Exception as e:
            print(f"No se pudo obtener información de {uri}: {e}")
        
        return info
    
    def validate_repo(self, repo_data: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Valida un repositorio
        
        Returns:
            Tupla (es_válido, mensaje_error)
        """
        # Validaciones básicas
        required_fields = ['uri', 'distribution', 'type']
        for field in required_fields:
            if not repo_data.get(field):
                return False, f"Campo requerido faltante: {field}"
        
        # Validar URI
        uri = repo_data['uri']
        if not (uri.startswith('http://') or uri.startswith('https://') or uri.startswith('ftp://')):
            return False, "URI debe comenzar con http://, https:// o ftp://"
        
        # Validar tipo
        if repo_data['type'] not in ['deb', 'deb-src']:
            return False, "Tipo debe ser 'deb' o 'deb-src'"
        
        # Validar distribución
        distribution = repo_data['distribution']
        if not re.match(r'^[a-zA-Z0-9\-_./]+$', distribution):
            return False, "Distribución contiene caracteres inválidos"
        
        return True, ""
    
    def save_repos(self, repos: List[Dict[str, Any]]) -> bool:
        """
        Guarda los repositorios en los archivos del sistema
        
        Args:
            repos: Lista de repositorios a guardar
            
        Returns:
            True si se guardaron correctamente, False en caso contrario
        """
        try:
            # Agrupar repositorios por archivo
            repos_by_file = {}
            for repo in repos:
                file_path = repo.get('file', self._determine_file_for_repo(repo))
                if file_path not in repos_by_file:
                    repos_by_file[file_path] = []
                repos_by_file[file_path].append(repo)
            
            # Guardar cada archivo
            for file_path, file_repos in repos_by_file.items():
                success = self.file_manager.write_sources_file(file_path, file_repos)
                if not success:
                    print(f"Error guardando archivo {file_path}")
                    return False
            
            # Invalidar caché
            self.cache_valid = False
            
            return True
            
        except Exception as e:
            print("Error guardando repositorios", e)
            return False
    
    def _determine_file_for_repo(self, repo: Dict[str, Any]) -> str:
        """Determina el archivo apropiado para un repositorio"""
        uri = repo.get('uri', '')
        distribution = repo.get('distribution', '')
        
        # Determinar extensión basada en el formato preferido
        extension = '.sources' if self.use_modern_format else '.list'
        
        # Reglas para determinar archivo
        if 'security.debian.org' in uri:
            return f'/etc/apt/sources.list.d/debian-security{extension}'
        elif 'deb.debian.org' in uri or 'debian.org' in uri:
            if 'backports' in distribution:
                return f'/etc/apt/sources.list.d/debian-backports{extension}'
            else:
                return f'/etc/apt/sources.list.d/debian{extension}'
        else:
            # Para repositorios de terceros, usar hostname
            try:
                from urllib.parse import urlparse
                hostname = urlparse(uri).netloc.replace('.', '-')
                return f'/etc/apt/sources.list.d/{hostname}{extension}'
            except:
                return f'/etc/apt/sources.list.d/custom{extension}'
    
    def add_repo(self, repo_data: Dict[str, Any]) -> bool:
        """
        Añade un nuevo repositorio
        
        Args:
            repo_data: Datos del repositorio a añadir
            
        Returns:
            True si se añadió correctamente
        """
        try:
            # Verificar si ya existe
            existing_repos = self.get_all_repos()
            for existing in existing_repos:
                if (existing['uri'] == repo_data['uri'] and 
                    existing['distribution'] == repo_data['distribution'] and
                    existing['type'] == repo_data['type']):
                    print("El repositorio ya existe")
                    return False
            
            # Determinar archivo de destino
            if 'file' not in repo_data:
                repo_data['file'] = self._determine_file_for_repo(repo_data)
            
            # Determinar formato
            if 'format' not in repo_data:
                repo_data['format'] = 'deb822' if self.use_modern_format else 'legacy'
            
            # Añadir a la lista existente
            existing_repos.append(repo_data)
            
            # Guardar
            return self.save_repos(existing_repos)
            
        except Exception as e:
            print("Error añadiendo repositorio", e)
            return False
    
    def remove_repo(self, uri: str, distribution: str, repo_type: str = 'deb') -> bool:
        """Elimina un repositorio"""
        try:
            repos = self.get_all_repos()
            original_count = len(repos)
            
            # Filtrar el repositorio a eliminar
            repos = [r for r in repos if not (
                r['uri'] == uri and 
                r['distribution'] == distribution and 
                r['type'] == repo_type
            )]
            
            if len(repos) == original_count:
                print("Repositorio no encontrado para eliminar")
                return False
            
            return self.save_repos(repos)
            
        except Exception as e:
            print("Error eliminando repositorio", e)
            return False
    
    def update_repo_indexes(self) -> bool:
        """Actualiza los índices de paquetes (apt update)"""
        try:
            return self.system_executor.run_apt_update()
        except Exception as e:
            print("Error actualizando índices", e)
            return False
    
    def clear_cache(self):
        """Limpia la caché de repositorios"""
        self.repo_cache = None
        self.cache_valid = False
        print("Caché de repositorios limpiada")
