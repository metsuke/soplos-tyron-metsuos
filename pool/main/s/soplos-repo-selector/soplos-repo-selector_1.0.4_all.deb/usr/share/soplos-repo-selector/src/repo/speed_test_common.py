"""
Biblioteca compartida para pruebas de velocidad de repositorios
"""
import time
import socket
import requests
import threading
from urllib.parse import urlparse
from pathlib import Path
from typing import Dict, List, Tuple, Callable, Optional, Any

from src.utils.error_handler import log_info, log_error, log_warning

class SpeedTesterBase:
    """Clase base con funcionalidad común para pruebas de velocidad"""
    
    def __init__(self, timeout: int = 5):
        self.timeout = timeout
        self.test_file_size = 512 * 1024  # 512KB para test rápido
        self.stop_requested = False
    
    def measure_latency(self, url: str) -> float:
        """
        Mide la latencia (tiempo de respuesta) a un servidor
        
        Args:
            url: URL del servidor a probar
        
        Returns:
            Latencia en milisegundos
        """
        hostname = urlparse(url).netloc
        
        try:
            start = time.time()
            socket.gethostbyname(hostname)
            return (time.time() - start) * 1000  # Convertir a ms
        except socket.gaierror:
            log_warning(f"No se pudo resolver el hostname {hostname}")
            return 9999  # Valor alto para indicar error
    
    def measure_download_speed(self, url: str) -> Dict[str, Any]:
        """
        Mide la velocidad de descarga real desde un repositorio
        
        Args:
            url: URL del repositorio a probar
        
        Returns:
            Diccionario con los resultados de la prueba
        """
        try:
            test_paths = [
                "dists/stable/Release",
                "dists/bookworm/Release",
                "ls-lR.gz"
            ]
            
            for test_path in test_paths:
                test_url = f"{url.rstrip('/')}/{test_path}"
                
                try:
                    start_time = time.time()
                    response = requests.get(test_url, timeout=self.timeout, stream=True)
                    
                    if response.status_code == 200:
                        downloaded = 0
                        download_start = time.time()
                        
                        for chunk in response.iter_content(chunk_size=8192):
                            downloaded += len(chunk)
                            if downloaded > self.test_file_size:
                                break
                        
                        elapsed = time.time() - download_start
                        
                        if elapsed > 0:
                            speed_mbps = (downloaded / (1024 * 1024)) / elapsed
                        else:
                            speed_mbps = 0
                        
                        return {
                            'speed_mbps': speed_mbps,
                            'latency_ms': elapsed * 1000,
                            'status': 'success',
                            'downloaded_bytes': downloaded
                        }
                except requests.exceptions.Timeout:
                    log_warning(f"Timeout al probar {test_url}")
                    continue
                except requests.exceptions.ConnectionError:
                    log_warning(f"Error de conexión al probar {test_url}")
                    continue
                except Exception as e:
                    log_error(f"Error al probar {test_url}", e)
                    continue
            
            return {'speed_mbps': 0, 'latency_ms': 9999, 'status': 'no_valid_files'}
                
        except requests.exceptions.Timeout:
            return {'speed_mbps': 0, 'latency_ms': 9999, 'status': 'timeout'}
        except requests.exceptions.ConnectionError:
            return {'speed_mbps': 0, 'latency_ms': 9999, 'status': 'connection_error'}
        except Exception as e:
            log_error(f"Error al medir velocidad para {url}", e)
            return {'speed_mbps': 0, 'latency_ms': 9999, 'status': 'error', 'error': str(e)}
    
    def format_speed_result(self, speed: float) -> str:
        """
        Formatea el resultado de velocidad para mostrar
        
        Args:
            speed: Velocidad en MB/s
            
        Returns:
            Texto formateado de la velocidad
        """
        if speed >= 1.0:
            return f"{speed:.2f} MB/s"
        else:
            # Si es menos de 1MB/s, mostrar en KB/s
            return f"{speed * 1024:.0f} KB/s"
    
    def get_speed_category(self, speed: float) -> str:
        """
        Categoriza la velocidad medida
        
        Args:
            speed: Velocidad en MB/s
            
        Returns:
            Categoría de velocidad ("excellent", "good", "normal", "slow")
        """
        if speed > 0.5:
            return "excellent"
        elif speed > 0.2:
            return "good"
        elif speed > 0.05:
            return "normal"
        else:
            return "slow"
    
    def get_country_from_url(self, url: str) -> str:
        """
        Determina el país probable de un mirror basado en su URL
        
        Args:
            url: URL del mirror
            
        Returns:
            Nombre del país o "Desconocido"
        """
        hostname = urlparse(url).netloc
        
        # Mapeo de dominios a países
        country_map = {
            "deb.debian.org": "Global CDN",
            "ftp.us.debian.org": "Estados Unidos",
            "ftp.uk.debian.org": "Reino Unido", 
            "ftp.de.debian.org": "Alemania",
            "ftp.fr.debian.org": "Francia",
            "ftp.au.debian.org": "Australia",
            "ftp.jp.debian.org": "Japón",
            "ftp.br.debian.org": "Brasil",
            "ftp.cl.debian.org": "Chile",
            "ftp.es.debian.org": "España",
            "ftp.it.debian.org": "Italia",
            "ftp.cn.debian.org": "China",
            "ftp.ru.debian.org": "Rusia",
            "ftp.ca.debian.org": "Canadá"
        }
        
        for domain, country in country_map.items():
            if domain in hostname:
                return country
        
        # Si no coincide con ninguno conocido, intentar extraer por convención ftp.XX.debian.org
        if hostname.endswith(".debian.org"):
            parts = hostname.split(".")
            if parts[0].startswith("ftp.") and len(parts[0]) > 4:
                country_code = parts[0][4:].upper()
                return f"Código: {country_code}"
        
        return "Desconocido"

# Lista de principais mirrors de Debian predefinidos
DEFAULT_MIRRORS = [
    "http://deb.debian.org/debian",
    "http://ftp.us.debian.org/debian",
    "http://ftp.uk.debian.org/debian",
    "http://ftp.de.debian.org/debian",
    "http://ftp.fr.debian.org/debian",
    "http://ftp.es.debian.org/debian",
    "http://ftp.it.debian.org/debian", 
    "http://ftp.br.debian.org/debian"
]

# Diccionario de repositorios organizados por país
def get_country_mirrors() -> Dict[str, List[str]]:
    """
    Proporciona un diccionario de repositorios organizados por país
    
    Returns:
        Diccionario con países como claves y listas de URLs como valores
    """
    return {
        'Global': ['http://deb.debian.org/debian'],
        'Estados Unidos': [
            'http://ftp.us.debian.org/debian',
            'http://mirrors.kernel.org/debian'
        ],
        'Reino Unido': [
            'http://ftp.uk.debian.org/debian',
            'http://mirror.bytemark.co.uk/debian'
        ],
        'Alemania': [
            'http://ftp.de.debian.org/debian',
            'http://ftp.gwdg.de/pub/linux/debian'
        ],
        'Francia': [
            'http://ftp.fr.debian.org/debian',
            'http://debian.mirrors.ovh.net/debian'
        ],
        'España': [
            'http://ftp.es.debian.org/debian',
            'http://debian.redimadrid.es/debian'
        ],
        'Italia': ['http://ftp.it.debian.org/debian'],
        'Brasil': ['http://ftp.br.debian.org/debian'],
        'Japón': ['http://ftp.jp.debian.org/debian'],
        'Australia': ['http://ftp.au.debian.org/debian'],
        'Canadá': ['http://ftp.ca.debian.org/debian'],
        'Rusia': ['http://ftp.ru.debian.org/debian'],
        'Suiza': ['http://ftp.ch.debian.org/debian'],
        'Suecia': ['http://ftp.se.debian.org/debian'],
        'Países Bajos': ['http://ftp.nl.debian.org/debian'],
        'China': ['http://ftp.cn.debian.org/debian']
    }
