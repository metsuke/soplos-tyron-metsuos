"""
Archivo de compatibilidad de redirección a la nueva estructura
Este archivo está obsoleto y se mantendrá solo temporalmente.
Por favor, use src.utils.config en su lugar.
"""

import warnings

from src.utils.config import Config

warnings.warn(
    "Importando desde utils.config está obsoleto. " +
    "Use src.utils.config en su lugar.",
    DeprecationWarning, 
    stacklevel=2
)
