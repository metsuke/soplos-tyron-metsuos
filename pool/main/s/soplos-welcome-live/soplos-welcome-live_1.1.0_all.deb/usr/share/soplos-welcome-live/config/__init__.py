import os
import sys

# Add root directory to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Configuration package

# Import necessary paths
from .paths import (
    LOGO_PATH,
    ICON_PATH,
    SLIDE_PATH,
    BASE_DIR,
    ASSETS_DIR,
    SLIDES_DIR,
    ICONS_DIR
)

# Import STRINGS from the strings package (not from strings.py)
from .strings import STRINGS

# Ensure assets directories exist
os.makedirs(ICONS_DIR, exist_ok=True)
os.makedirs(SLIDES_DIR, exist_ok=True)

__all__ = ['STRINGS', 'LOGO_PATH', 'ICON_PATH', 'SLIDE_PATH', 'BASE_DIR', 'ASSETS_DIR', 'ICONS_DIR', 'SLIDES_DIR']