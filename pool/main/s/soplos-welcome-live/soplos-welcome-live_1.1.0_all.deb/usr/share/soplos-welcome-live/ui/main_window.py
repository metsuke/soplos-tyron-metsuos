import gi
import os
import subprocess
import sys
import shutil  # Add shutil import

# Add root directory to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GdkPixbuf, Gdk, GLib
from ui.welcome_tab import WelcomeTab
from config.paths import LOGO_PATH, ICON_PATH  # Add ICON_PATH to import
from config.strings import STRINGS  # Change import
from utils.autostart import AutostartManager
from ui.chroot_window import ChRootWindow

# Dictionary of languages and their configurations (moved from welcome_tab.py)
LANGUAGES = {
    'Español': {'locale': 'es_ES.UTF-8', 'layout': 'es'},
    'English': {'locale': 'en_US.UTF-8', 'layout': 'us'},
    'Português': {'locale': 'pt_PT.UTF-8', 'layout': 'pt'},
    'Français': {'locale': 'fr_FR.UTF-8', 'layout': 'fr'},
    'Deutsch': {'locale': 'de_DE.UTF-8', 'layout': 'de'},
    'Italiano': {'locale': 'it_IT.UTF-8', 'layout': 'it'},
    'Română': {'locale': 'ro_RO.UTF-8', 'layout': 'ro'},
    'Русский': {'locale': 'ru_RU.UTF-8', 'layout': 'ru'}
}

class MainWindow(Gtk.ApplicationWindow):  # Change from Gtk.Window to Gtk.ApplicationWindow
    def __init__(self):
        super().__init__()
        
        # Set WM_CLASS to match .desktop file
        self.set_wmclass("com.soplos.welcomelive", "com.soplos.welcomelive")
        
        # Set window icon explicitly
        try:
            icon_theme = Gtk.IconTheme.get_default()
            try:
                icon = icon_theme.load_icon("com.soplos.welcomelive", 128, 0)
                self.set_icon(icon)
            except:
                # Fallback to absolute path if name loading fails
                if os.path.exists(ICON_PATH):
                    self.set_icon_from_file(ICON_PATH)
        except Exception as e:
            print(f"Error setting icon: {e}")
        
        app = Gtk.Application.get_default()
        Gtk.ApplicationWindow.__init__(self, application=app)
        self.set_title("Soplos Welcome Live")
        
        # Detect current system language safely
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        # If it's C.UTF-8 or similar, use English by default
        if current_locale.startswith('C.') or current_locale == 'C':
            self.current_lang = 'en'
        else:
            self.current_lang = current_locale.split('_')[0]
            # If language doesn't exist in STRINGS, use English
            if self.current_lang not in STRINGS:
                self.current_lang = 'en'
        
        # Search for language name in LANGUAGES
        current_language_name = None
        for name, config in LANGUAGES.items():
            if config['locale'].startswith(current_locale[:5]):
                current_language_name = name
                break
        
        Gtk.Window.__init__(self, title=STRINGS[self.current_lang]['welcome'])
        self.set_wmclass('soplos-welcome-live', 'soplos-welcome-live')
        
        self.set_border_width(10)
        
        self.set_default_size(800, 400)
        self.set_position(Gtk.WindowPosition.CENTER)
        
        # Main horizontal container
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(main_box)
        
        # Sub-container horizontal for logo and content
        content_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        main_box.pack_start(content_box, True, True, 0)

        # Left panel for logo (now goes in content_box)
        left_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        left_panel.set_size_request(200, -1)
        content_box.pack_start(left_panel, False, False, 5)

        try:
            header_pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                filename=LOGO_PATH,
                width=150,
                height=150,
                preserve_aspect_ratio=True
            )
            logo_image = Gtk.Image.new_from_pixbuf(header_pixbuf)
            left_panel.pack_start(logo_image, False, False, 10)
        except Exception as e:
            print(f"Error loading logo: {e}")
        
        welcome_label = Gtk.Label()
        welcome_label.set_markup(
            f"<span size='large' weight='bold'>{STRINGS[self.current_lang]['welcome']}</span>\n" +
            f"<span size='small'>{STRINGS[self.current_lang]['thanks']}</span>"
        )
        welcome_label.set_justify(Gtk.Justification.CENTER)
        welcome_label.set_line_wrap(True)
        left_panel.pack_start(welcome_label, False, False, 5)
        
        # Add flexible space that will push language selector down
        left_panel.pack_start(Gtk.Box(), True, True, 0)
        
        # Language selector and autostart in left panel
        controls_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        left_panel.pack_end(controls_box, False, False, 0)

        # NumLockX switch - RESTORE FUNCTIONALITY
        numlockx_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        numlockx_label = Gtk.Label(label=STRINGS[self.current_lang]['labels']['numlockx'])  # Use internationalized text
        numlockx_box.pack_start(numlockx_label, False, False, 0)
        
        self.numlockx_switch = Gtk.Switch()
        # Check initial numlockx state
        from utils.numlockx_manager import NumlockxManager
        numlockx_manager = NumlockxManager()
        self.numlockx_switch.set_active(numlockx_manager.is_enabled())
        self.numlockx_switch.connect("notify::active", self.on_numlockx_toggled)
        numlockx_box.pack_end(self.numlockx_switch, False, False, 0)
        
        controls_box.pack_start(numlockx_box, False, False, 5)

        # Autostart switch
        autostart_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        autostart_label = Gtk.Label(label=STRINGS[self.current_lang]['labels']['show_startup'])
        autostart_box.pack_start(autostart_label, False, False, 0)
        
        self.autostart_switch = Gtk.Switch()
        self.autostart_manager = AutostartManager()
        self.autostart_switch.set_active(self.autostart_manager.is_enabled())
        self.autostart_switch.connect("notify::active", self.on_autostart_toggled)
        autostart_box.pack_end(self.autostart_switch, False, False, 0)
        
        controls_box.pack_start(autostart_box, False, False, 5)
        
        # Language selector in left panel, now aligns with exit button
        lang_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        lang_box.set_margin_bottom(5)  # Bottom margin to align with exit button
        controls_box.pack_start(lang_box, False, False, 0)  # Use pack_end instead of pack_start
        
        lang_label = Gtk.Label(label=STRINGS[self.current_lang]['labels']['language'])
        lang_box.pack_start(lang_label, False, False, 0)
        
        self.lang_combo = Gtk.ComboBoxText()
        # Add languages and save current language index
        current_index = 0
        for i, (lang, config) in enumerate(LANGUAGES.items()):
            self.lang_combo.append_text(lang)
            if config['locale'].startswith(current_locale[:5]):
                current_index = i
        
        # Select current language by index
        self.lang_combo.set_active(current_index)
        self.lang_combo.connect("changed", self.on_language_changed)
        lang_box.pack_start(self.lang_combo, True, True, 5)
        
        # Right panel (now goes in content_box)
        right_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        content_box.pack_start(right_panel, True, True, 0)
        
        welcome_tab = WelcomeTab(self)
        right_panel.pack_start(welcome_tab, True, True, 0)
        
        # Bottom panel with buttons
        button_panel = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        right_panel.pack_end(button_panel, False, False, 5)

        # Buttons (maintain existing order)
        exit_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['exit'])
        exit_button.set_use_underline(True)
        exit_button.connect("clicked", self.on_exit_clicked)
        button_panel.pack_end(exit_button, False, False, 0)

        chroot_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['chroot'])
        chroot_button.set_use_underline(True)
        chroot_button.connect("clicked", self.on_chroot_clicked)
        button_panel.pack_end(chroot_button, False, False, 5)

        install_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['install'])
        install_button.set_use_underline(True)
        install_button.connect("clicked", self.on_install_clicked)
        install_button.get_style_context().add_class("install-button")
        button_panel.pack_end(install_button, False, False, 5)

        # Progress bar at end of main_box
        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_show_text(False)  # Initially without text
        self.progress_bar.set_visible(False)
        main_box.pack_end(self.progress_bar, False, True, 0)

        # Add CSS for install button
        css_provider = Gtk.CssProvider()
        css = b"""
            .install-button {
                background: #e95420;
                color: white;
                padding: 5px 10px;
                font-weight: bold;
            }
            .install-button:hover {
                background: #e9662b;
            }
        """
        css_provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
    
    def on_language_changed(self, combo):
        """Handle language change"""
        lang_name = combo.get_active_text()
        lang_config = LANGUAGES[lang_name]
        
        # Show progress bar with text
        self.progress_bar.set_visible(True)
        self.progress_bar.set_show_text(True)  # Now show text
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text(STRINGS[self.current_lang]['progress']['configuring'])
        
        try:
            # Update progress bar while performing tasks
            self.progress_bar.set_fraction(0.2)
            while Gtk.events_pending():
                Gtk.main_iteration()

            # Check which file exists and modify it appropriately
            # Generally one is a symbolic link to the other
            locale_conf = '/etc/locale.conf'
            debian_locale = '/etc/default/locale'
            
            # Create content for locale configuration
            locale_content = f'LANG={lang_config["locale"]}\n'
            
            # Determine which file to modify (prefer /etc/locale.conf if exists)
            target_file = locale_conf if os.path.exists(locale_conf) else debian_locale
            
            # Write to appropriate file
            subprocess.run(['pkexec', 'bash', '-c', f'echo "{locale_content}" > {target_file}'], 
                         check=True, capture_output=True)

            self.progress_bar.set_fraction(0.4)
            while Gtk.events_pending():
                Gtk.main_iteration()
            
            # Configure keyboard layout
            subprocess.run(['setxkbmap', lang_config['layout']], check=True)
            
            # Make change permanent
            xorg_conf = f"""Section "InputClass"
        Identifier "system-keyboard"
        MatchIsKeyboard "on"
        Option "XkbLayout" "{lang_config['layout']}"
EndSection"""
            
            # Create directory if it doesn't exist
            os.makedirs("/etc/X11/xorg.conf.d", exist_ok=True)
            
            # Write configuration
            subprocess.run(['pkexec', 'bash', '-c', 
                          f'echo \'{xorg_conf}\' > /etc/X11/xorg.conf.d/00-keyboard.conf'],
                         check=True, capture_output=True)

            self.progress_bar.set_fraction(0.6)
            while Gtk.events_pending():
                Gtk.main_iteration()

            # Migrate XDG folders
            home_dir = os.path.expanduser('~')
            
            # 1. Get current and new folder names
            old_dirs = {}
            with open(os.path.join(home_dir, '.config/user-dirs.dirs'), 'r') as f:
                for line in f:
                    if line.startswith('XDG_'):
                        key, value = line.strip().split('=')
                        old_dirs[key] = value.strip('"').replace('$HOME/', '')

            # 2. Force update names with new language
            subprocess.run(['env', f'LANG={lang_config["locale"]}', 'xdg-user-dirs-update', '--force'])
            
            # 3. Get new names post-update
            new_dirs = {}
            with open(os.path.join(home_dir, '.config/user-dirs.dirs'), 'r') as f:
                for line in f:
                    if line.startswith('XDG_'):
                        key, value = line.strip().split('=')
                        new_dirs[key] = value.strip('"').replace('$HOME/', '')

            # 4. Migrate content safely
            for key in old_dirs:
                old_path = os.path.join(home_dir, old_dirs[key])
                new_path = os.path.join(home_dir, new_dirs[key])
                
                if os.path.exists(old_path):
                    # If new folder already exists, move content
                    if os.path.exists(new_path):
                        try:
                            # Move all content from old_path to new_path
                            for item in os.listdir(old_path):
                                old_item = os.path.join(old_path, item)
                                new_item = os.path.join(new_path, item)
                                # If destination doesn't exist, move
                                if not os.path.exists(new_item):
                                    shutil.move(old_item, new_item)
                        except (shutil.Error, OSError) as e:
                            print(f"Error moving {old_item}: {e}")
                            continue
                    else:
                        # If new folder doesn't exist, rename directly
                        try:
                            shutil.move(old_path, new_path)
                        except (shutil.Error, OSError) as e:
                            print(f"Error renaming {old_path}: {e}")
                            continue
                
                # Try to remove old folder if empty
                try:
                    if os.path.exists(old_path) and not os.listdir(old_path):
                        os.rmdir(old_path)
                except OSError:
                    continue

            # 5. Update xdg-user-dirs configuration
            subprocess.run(['xdg-user-dirs-update'])

            # 6. Restore XFCE configuration to show only home and trash
            xfce_config = os.path.expanduser('~/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-desktop.xml')
            if os.path.exists(xfce_config):
                # Make backup of original file
                shutil.copy2(xfce_config, f"{xfce_config}.bak")
                
                # Enable desktop icons
                subprocess.run([
                    'xfconf-query',
                    '--channel', 'xfce4-desktop',
                    '--property', '/desktop-icons/style',
                    '--set', '2'  # Changed from 0 to 2 to show icons
                ])
                
                # Configure which icons to show
                subprocess.run([
                    'xfconf-query',
                    '--channel', 'xfce4-desktop',
                    '--property', '/desktop-icons/file-icons/show-filesystem',
                    '--set', 'false'
                ])
                subprocess.run([
                    'xfconf-query',
                    '--channel', 'xfce4-desktop',
                    '--property', '/desktop-icons/file-icons/show-home',
                    '--set', 'true'  # Show home folder
                ])
                subprocess.run([
                    'xfconf-query',
                    '--channel', 'xfce4-desktop',
                    '--property', '/desktop-icons/file-icons/show-trash',
                    '--set', 'true'  # Show trash
                ])
                subprocess.run([
                    'xfconf-query',
                    '--channel', 'xfce4-desktop',
                    '--property', '/desktop-icons/file-icons/show-removable',
                    '--set', 'false'
                ])

            self.progress_bar.set_fraction(0.8)
            while Gtk.events_pending():
                Gtk.main_iteration()

            # Restart LightDM after migration
            subprocess.run(['pkexec', 'systemctl', 'restart', 'lightdm'], 
                         check=True, capture_output=True)

            self.progress_bar.set_fraction(1.0)
            while Gtk.events_pending():
                Gtk.main_iteration()

        except subprocess.CalledProcessError as e:
            self.progress_bar.set_visible(False)
            error_msg = e.stderr.decode() if e.stderr else str(e)
            self.show_error_dialog(f"{STRINGS[self.current_lang]['locale']['error_generating']}\n{error_msg}")
    
    def show_error_dialog(self, message):
        """Show error dialog"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=message
        )
        dialog.run()
        dialog.destroy()

    def on_exit_clicked(self, widget):
        """Handle exit button click"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=STRINGS[self.current_lang]['dialog']['exit_title']
        )
        dialog.format_secondary_text(STRINGS[self.current_lang]['dialog']['exit_desc'])
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            app = self.get_application()
            if app:
                app.quit()
    
    def on_window_destroy(self, window):
        """Handle destroy signal"""
        app = self.get_application()
        if app:
            app.quit()

    def on_chroot_clicked(self, button):
        """Open CHROOT window"""
        os.environ['NO_AT_BRIDGE'] = '1'
        os.environ['GTK_MODULES'] = ''
        os.environ['DBUS_SESSION_BUS_ADDRESS'] = ''
        os.environ['XDG_RUNTIME_DIR'] = f"/run/user/{os.getuid()}"
        os.environ['DISPLAY'] = ':0'
        
        from ui.chroot_window import ChRootWindow
        chroot_window = ChRootWindow()
        chroot_window.show_all()

    def on_gparted_clicked(self, button):
        """Execute GParted"""
        os.system('sudo gparted')  # Use os.system directly

    def on_install_clicked(self, button):
        """Execute Calamares installer"""
        subprocess.Popen(['sudo', 'calamares'])  # First execute calamares
        GLib.timeout_add(1000, lambda: self.destroy())  # Then destroy window after 1 second

    def on_autostart_toggled(self, switch, gparam):
        """Handle autostart switch change"""
        if switch.get_active():
            self.autostart_manager.enable()
        else:
            self.autostart_manager.disable()

    def on_numlockx_toggled(self, switch, gparam):
        """Handle numlockx switch change - RESTORE FUNCTIONALITY"""
        from utils.numlockx_manager import NumlockxManager
        
        numlockx_manager = NumlockxManager()
        try:
            if switch.get_active():
                numlockx_manager.enable_numlockx()
            else:
                numlockx_manager.disable_numlockx()
        except Exception as e:
            self.show_error_dialog(str(e))