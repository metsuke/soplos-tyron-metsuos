# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://sempaver.org/).

## [1.1.1] - 2025-09-08

### ✨ Changed - Welcome tab links
- Updated links in the welcome tab buttons.

## [1.1.0] - 2025-08-02

### ✨ Changed - Internationalization and btrfs support
- Complete internationalization refactor: dictionaries are now split into 8 files for easier maintenance and language addition.
- All issues and errors with btrfs partition mounting and subvolume selection in CHROOT have been fixed.

## [1.0.9] - 2025-07-27

### ✨ Changed - Icon
- New program icon. Visual refresh for better integration with Soplos Linux branding.
- Author: Sergi Perich

## [1.0.8] - 2025-07-27

### ✨ Added - Advanced partition detection and support
- Advanced detection and selection of partitions and btrfs subvolumes in the chroot environment.
- Full support for mounting /home as a partition or btrfs subvolume.
- Improved robustness of the recovery flow and compatibility with multiple terminals.
- Author changed to Sergi Perich.

## [1.0.7] - 2025-07-27

### ✨ Added - Advanced partition detection and support
- Advanced detection and selection of partitions and btrfs subvolumes in the chroot environment.
- Full support for mounting /home as a partition or btrfs subvolume.
- Improved robustness of the recovery flow and compatibility with multiple terminals.
- Author changed to Sergi Perich.

## [1.0.6] - 2025-07-18

### 🛠️ Improved - Metainfo and AppStream/DEP-11 compatibility
- Metainfo update for AppStream/DEP-11 compliance.
- Minor improvements in integration and documentation.
- Full validation for software centers.
- No functional changes in the application.

## [1.0.5] - 2025-07-10

### 🌍 Added - Recovery and support
- Full support for btrfs subvolumes in CHROOT recovery.
- Complete internationalization in 8 languages with mnemonics.

### 🐛 Fixed - Strings and texts
- Correction and review of all dictionary text strings.

## [1.0.4] - 2024-01-28

### ✨ New advanced CHROOT functionality
- Intelligent partition detection.
- NumLock integration and automatic XDG folder migration.
- Real-time Python cache cleanup and memory optimization.
- GParted integration and robust filesystem validation.
- Complete internationalization in 8 languages.

## [1.0.3] - 2024-01-26

### 🌐 Internationalization improvements
- Locale configuration fixes.
- Interface optimizations.

## [1.0.2] - 2024-01-25

### ⚙️ Hardware detection improvements
- CHROOT operation fixes.
- General stability improvements.

## [1.0.1] - 2024-01-24

### 🐛 Minor bug fixes
- User interface improvements.
- Configuration optimizations.

## [1.0.0] - 2024-01-27

### 🎉 Initial Release
- Basic welcome interface.
- Basic CHROOT functionality.
- Initial multi-language support.

---

## Types of Changes

- **Added** for new features
- **Improved** for changes in existing functionality
- **Deprecated** for soon-to-be removed features
- **Removed** for now removed features
- **Fixed** for any bug fixes
- **Security** for vulnerabilities

## Contributing

To report bugs or request features:
- **Issues**: https://github.com/SoplosLinux/tyron/issues
- **Email**: info@soploslinux.com

## Support

- **Documentation**: https://soploslinux.com/foros/
- **Community**: https://soploslinux.com/foros/
- **Support**: info@soploslinux.com
