# Soplos Welcome Live

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.1.1-green.svg)]()

Welcome screen for Soplos Linux Live Environment that helps users navigate the system and perform installation.

## 📝 Description

An advanced welcome application for the Soplos Linux Live environment that provides a complete experience for system configuration, installation, and recovery. It includes specialized tools for system administrators and advanced users.

## ✨ Main Features

### 🎯 Installation and Configuration
- **Direct installation** with Calamares integration
- **Automatic language configuration** with full support for 8 languages
- **Intelligent XDG folder migration** when changing language
- **Automatic locale detection** from the system
- **Keyboard configuration** synchronized with the selected language

### 🛠️ Recovery Tools
- **Advanced CHROOT system** for complete system recovery
- **Intelligent partition detection** with automatic mount suggestions
- **Specialized recovery terminal** with preconfigured commands
- **Safe filesystem mounting** with automatic validation
- **GParted integration** for advanced disk management

### ⚙️ System Configuration
- **NumLock control** for automatic activation of the numeric keypad
- **Autostart management** for the welcome application
- **Persistent user preferences**
- **Full support for EFI and BIOS systems**

### 🌐 Complete Internationalization
- **8 supported languages** with professional translations
- **Mnemonics (keyboard shortcuts)** in all languages
- **Cultural adaptation** of messages and formats
- **Automatic system language detection**
- **User folder migration** according to the selected language

### 🔧 Advanced Technical Features
- **Automatic Python cache cleanup** in real time
- **Advanced memory management** with periodic cleanup
- **Robust hardware detection** with support for multiple disk types
- **Filesystem validation** before CHROOT mounting
- **Intelligent error handling** with automatic recovery

## 📸 Screenshots

### Live Welcome Screen
![Welcome Screen](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-welcome-live/screenshots/screenshot1.png)

### CHROOT Recovery Tools
![CHROOT Recovery](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-welcome-live/screenshots/screenshot2.png)

### Multi-language Configuration
![Language Configuration](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-welcome-live/screenshots/screenshot3.png)

## 🔧 Installation

```bash
sudo apt update
sudo apt install soplos-welcome-live
```

### Dependencies
- `python3` (≥3.8)
- `python3-gi`
- `gir1.2-gtk-3.0`
- `calamares` (recommended)
- `gparted` (recommended)
- `locales`
- `x11-xkb-utils`
- `ptyxis` or compatible terminal

## 🌐 Supported Languages

| Language  | Code | Status      |
|-----------|------|-------------|
| Spanish   | `es` | ✅ Complete |
| English   | `en` | ✅ Complete |
| Portuguese| `pt` | ✅ Complete |
| French    | `fr` | ✅ Complete |
| German    | `de` | ✅ Complete |
| Italian   | `it` | ✅ Complete |
| Romanian  | `ro` | ✅ Complete |
| Russian   | `ru` | ✅ Complete |

## 🚀 Usage

### Automatic Start
The application starts automatically in the Live environment. It can be disabled from the interface.

### System Installation
1. Select the desired language
2. Click "Install Soplos Linux"
3. Follow the Calamares installer wizard

### CHROOT Recovery
1. Click "Recover system with CHROOT"
2. Select the disk of the installed system
3. Choose the appropriate partitions
4. Work in the recovery environment

### NumLock Configuration
- Use the "Activate numeric keypad" switch to configure NumLock
- The setting is applied to the installed system during installation

## 🛠️ Development

### Project Structure
```
soplos-welcome-live/
├── main.py                 # Main entry point
├── ui/                     # User interface
│   ├── main_window.py      # Main window
│   ├── welcome_tab.py      # Welcome tab
│   └── chroot_window.py    # CHROOT recovery window
├── config/                 # Configuration
│   ├── strings.py          # Translated strings
│   └── paths.py            # Resource paths
├── core/                   # Core logic
│   └── chroot_operations.py # CHROOT operations
├── utils/                  # Utilities
│   ├── autostart.py        # Autostart management
│   └── numlockx_manager.py # NumLock management
└── assets/                 # Graphic resources
    ├── icons/              # Icons
    └── slides/             # Presentation images
```

### Development Requirements
```bash
pip install -r requirements.txt
```

## 📄 License

This project is licensed under [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html) (GNU General Public License version 3 or later).

This license guarantees the following freedoms:
- ✅ The freedom to use the program for any purpose
- ✅ The freedom to study how the program works and modify it
- ✅ The freedom to distribute copies of the program
- ✅ The freedom to improve the program and publish those improvements

Any derivative work must be distributed under the same license (GPL-3.0+).

For more details, see the LICENSE file or visit [gnu.org/licenses/gpl-3.0](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Developers

Developed by Sergi Perich

## 🔗 Links

- [Official website](https://soploslinux.com)
- [GitHub Repository](https://github.com/SoplosLinux/tyron)
- [Report Issues](https://github.com/SoplosLinux/tyron/issues)
- [Community Forums](https://soploslinux.com/foros/)
- [Wiki and documentation](https://sourceforge.net/p/soplos-linux/wiki/Home/)
- [Contact](mailto:info@soploslinux.com)

## 📦 Version History

### v1.1.1 (09/08/2025)
- Updated links in the welcome tab buttons.

### v1.1.0 (08/02/2025)
- Complete internationalization refactor: dictionaries are now split into 8 files for easier maintenance and language addition.
- All issues and errors with btrfs partition mounting and subvolume selection in CHROOT have been fixed.

### v1.0.9 (07/27/2025)
- New program icon. Visual refresh for better integration with Soplos Linux branding.

### v1.0.8 (07/27/2025)
- Advanced detection and selection of partitions and btrfs subvolumes in the chroot environment.
- Full support for mounting /home as a partition or btrfs subvolume.
- Improved robustness of the recovery flow and compatibility with multiple terminals.
- Author changed to Sergi Perich.

### v1.0.7 (07/27/2025)
- Advanced detection and selection of partitions and btrfs subvolumes in the chroot environment.
- Full support for mounting /home as a partition or btrfs subvolume.
- Improved robustness of the recovery flow and compatibility with multiple terminals.
- Author changed to Sergi Perich.

### v1.0.6 (07/18/2025)
- 🛠️ Improved - Metainfo and AppStream/DEP-11 compatibility
  - Metainfo update for AppStream/DEP-11 compliance.
  - Minor improvements in integration and documentation.
  - Full validation for software centers.
  - No functional changes in the application.

### v1.0.5 (07/10/2025)
- 🌍 Added: Full support for btrfs subvolumes in CHROOT recovery.
- 🌐 Complete internationalization in 8 languages with mnemonics.
- 🐛 Fixed: Correction and review of all dictionary text strings.

### v1.0.4 (01/28/2024)
- ✨ New advanced CHROOT functionality with intelligent partition detection
- 🌐 Complete internationalization in 8 languages with mnemonics
- ⚙️ Integrated NumLock management in the system
- 🔧 Automatic XDG folder migration when changing language
- 🛠️ Real-time Python cache cleanup
- 🎯 Robust filesystem detection for CHROOT
- 📱 Improved interface with better visual organization
- 🚀 Performance optimization and memory management

### v1.0.3 (01/26/2024)
- 🌐 Internationalization improvements
- 🔧 Locale configuration fixes
- 📱 Interface optimizations

### v1.0.2 (01/25/2024)
- ⚙️ Hardware detection improvements
- 🛠️ CHROOT operation fixes
- 🎯 General stability improvements

### v1.0.1 (01/24/2024)
- 🐛 Minor bug fixes
- 📱 User interface improvements
- 🔧 Configuration optimizations

### v1.0.0 (01/27/2024)
- 🎉 Initial release version
- 📱 Basic welcome interface
- 🛠️ Basic CHROOT functionality
- 🌐 Initial multi-language support

---

**Soplos Welcome Live v1.1.1** - The ultimate tool for the Soplos Linux Live environment
