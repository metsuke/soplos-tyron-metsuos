from setuptools import setup, find_packages

setup(
    name="soplos-welcome-live",
    version="1.1.1",  # Updated version
    packages=find_packages(),
    install_requires=[
        'PyGObject>=3.40.0',
    ],
    data_files=[
        ('share/icons/hicolor/128x128/apps', ['assets/icons/com.soplos.welcomelive.png']),
        ('share/metainfo', ['debian/com.soplos.welcomelive.metainfo.xml']),
        ('share/applications', ['assets/com.soplos.welcomelive.desktop'])
    ],
    entry_points={
        'console_scripts': [
            'soplos-welcome-live=main:main',
        ],
    },
    author="Sergi Perich",
    author_email="info@soploslinux.com",
    description="Advanced welcome screen for Soplos Linux Live Environment with btrfs support",
    long_description="Complete internationalization support, advanced CHROOT recovery with btrfs subvolume support, and professional system administration capabilities.",
    license="GPL-3.0+",
    url="https://soploslinux.com",
    project_urls={
        "Bug Tracker": "https://github.com/SoplosLinux/tyron/issues",
        "Documentation": "https://soploslinux.com/foros/",
        "Source Code": "https://github.com/SoplosLinux/tyron"
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: End Users/Desktop",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: GNU General Public License v3 or later (GPLv3+)",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Desktop Environment",
        "Topic :: System :: Installation/Setup",
        "Topic :: System :: Recovery Tools",
        "Topic :: System :: Systems Administration"
    ],
    python_requires=">=3.8",
    keywords="welcome live system recovery chroot btrfs soplos linux administration"
)
