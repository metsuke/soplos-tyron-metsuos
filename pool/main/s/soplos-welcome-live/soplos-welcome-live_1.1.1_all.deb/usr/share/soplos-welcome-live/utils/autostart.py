import os
import shutil
from config.strings import STRINGS

class AutostartManager:
    def __init__(self):
        self.autostart_dir = os.path.expanduser('~/.config/autostart')
        self.desktop_source = '/usr/share/applications/com.soplos.welcomelive.desktop'
        self.desktop_target = os.path.join(self.autostart_dir, 'com.soplos.welcomelive.desktop')

    def is_enabled(self):
        """Check if welcome-live is in autostart"""
        return os.path.exists(self.desktop_target)

    def toggle(self):
        """Enable/disable autostart"""
        if self.is_enabled():
            # Disable
            if os.path.exists(self.desktop_target):
                os.remove(self.desktop_target)
        else:
            # Enable
            os.makedirs(self.autostart_dir, exist_ok=True)
            if os.path.exists(self.desktop_source):
                shutil.copy2(self.desktop_source, self.desktop_target)
            # No print, silent fail if not found

    def enable(self):
        """Enable autostart"""
        if not self.is_enabled():
            os.makedirs(self.autostart_dir, exist_ok=True)
            if os.path.exists(self.desktop_source):
                shutil.copy2(self.desktop_source, self.desktop_target)
            # No print, silent fail if not found

    def disable(self):
        """Disable autostart"""
        if os.path.exists(self.desktop_target):
            os.remove(self.desktop_target)