#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys

from config.strings import STRINGS

def force_cleanup():
    """Force cleanup using system tools"""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    current_locale = os.getenv('LANG', 'en_US.UTF-8')
    lang = current_locale.split('_')[0] if '_' in current_locale else 'en'
    if lang not in STRINGS:
        lang = 'en'

    print(STRINGS[lang]['messages'].get('force_cleanup_start', 'Starting force cleanup...'))
    
    # Use find to remove all __pycache__ directories
    try:
        subprocess.run([
            'find', base_dir, '-type', 'd', '-name', '__pycache__', 
            '-exec', 'rm', '-rf', '{}', '+'
        ], check=True, capture_output=True)
        print(STRINGS[lang]['messages'].get('force_cleanup_pycache', 'Removed __pycache__ directories with find'))
    except:
        pass
    
    # Use find to remove .pyc files
    try:
        subprocess.run([
            'find', base_dir, '-name', '*.pyc', '-delete'
        ], check=True, capture_output=True)
        print(STRINGS[lang]['messages'].get('force_cleanup_pyc', 'Removed .pyc files with find'))
    except:
        pass
    
    # Use find to remove .pyo files
    try:
        subprocess.run([
            'find', base_dir, '-name', '*.pyo', '-delete'
        ], check=True, capture_output=True)
        print(STRINGS[lang]['messages'].get('force_cleanup_pyo', 'Removed .pyo files with find'))
    except:
        pass
    
    print(STRINGS[lang]['messages'].get('force_cleanup_done', 'Force cleanup completed'))

if __name__ == "__main__":
    force_cleanup()
