"""
Internationalized text strings module for Soplos Welcome Live
Supports 8 languages: Spanish, English, Portuguese, French, German, Italian, Romanian and Russian
"""

# Import all translations
from .es import STRINGS_ES
from .en import STRINGS_EN
from .pt import STRINGS_PT
from .fr import STRINGS_FR
from .de import STRINGS_DE
from .it import STRINGS_IT
from .ro import STRINGS_RO
from .ru import STRINGS_RU

# Combine all translations into the main dictionary
STRINGS = {
    'es': STRINGS_ES,
    'en': STRINGS_EN,
    'pt': STRINGS_PT,
    'fr': STRINGS_FR,
    'de': STRINGS_DE,
    'it': STRINGS_IT,
    'ro': STRINGS_RO,
    'ru': STRINGS_RU
}

# List of available languages
AVAILABLE_LANGUAGES = list(STRINGS.keys())

# Mapping of language codes to native names
LANGUAGE_NAMES = {
    'es': 'Español',
    'en': 'English',
    'pt': 'Português',
    'fr': 'Français',
    'de': 'Deutsch',
    'it': 'Italiano',
    'ro': 'Română',
    'ru': 'Русский'
}
