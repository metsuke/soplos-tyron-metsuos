#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Configure environment variables before importing GTK
import os
import sys

# Prevent creation of .pyc files from startup
sys.dont_write_bytecode = True

# Define base_dir as global variable at startup
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

os.environ['NO_AT_BRIDGE'] = '1'
os.environ['GTK_MODULES'] = ''
os.environ['DBUS_SESSION_BUS_ADDRESS'] = ''

import gi
import shutil
import subprocess  # Add this import
import atexit  # Add for cleanup on exit

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, Gio  # Add Gio
from ui.main_window import MainWindow
from config.strings import STRINGS
from config.paths import ICON_PATH  # Add this import

def clean_pycache():
    """Clean all __pycache__, .pyc and .pyo files from project"""
    # Use global BASE_DIR variable
    base_dir = BASE_DIR
    
    # List of patterns to clean
    patterns_to_clean = [
        '**/__pycache__',
        '**/*.pyc',
        '**/*.pyo',
        '**/*.pyd'
    ]
    
    import glob
    
    for pattern in patterns_to_clean:
        full_pattern = os.path.join(base_dir, pattern)
        
        # Find files/folders matching the pattern
        try:
            matches = glob.glob(full_pattern, recursive=True)
            
            for match in matches:
                try:
                    if os.path.isdir(match):
                        shutil.rmtree(match, ignore_errors=True)
                        # print(f"Removed directory: {match}")
                    elif os.path.isfile(match):
                        os.remove(match)
                        # print(f"Removed file: {match}")
                except (OSError, PermissionError) as e:
                    # print(f"Could not remove {match}: {e}")
                    pass
        except Exception:
            continue  # Ignore glob errors

    # Additional manual cleanup for specific directories
    specific_dirs = ['utils', 'ui', 'config', 'core']
    for dir_name in specific_dirs:
        try:
            dir_path = os.path.join(base_dir, dir_name)
            if os.path.exists(dir_path):
                pycache_path = os.path.join(dir_path, '__pycache__')
                if os.path.exists(pycache_path):
                    try:
                        shutil.rmtree(pycache_path, ignore_errors=True)
                        # print(f"Removed specific directory: {pycache_path}")
                    except Exception as e:
                        # print(f"Error removing {pycache_path}: {e}")
                        pass
        except Exception:
            continue

def aggressive_cleanup():
    """Aggressive cleanup that runs continuously"""
    try:
        # Use global BASE_DIR instead of __file__
        base_dir = BASE_DIR
        
        # Find and remove any __pycache__ that appears
        for root, dirs, files in os.walk(base_dir):
            try:
                for dir_name in dirs[:]:  # use slice to be able to modify the list
                    if dir_name == '__pycache__':
                        pycache_path = os.path.join(root, dir_name)
                        try:
                            shutil.rmtree(pycache_path, ignore_errors=True)
                            dirs.remove(dir_name)  # remove from list to not process again
                            # print(f"Auto-removed: {pycache_path}")
                            pass
                        except:
                            pass
                
                # Remove individual .pyc files
                for file_name in files:
                    if file_name.endswith(('.pyc', '.pyo', '.pyd')):
                        file_path = os.path.join(root, file_name)
                        try:
                            os.remove(file_path)
                            # print(f"Removed file: {file_path}")
                            pass
                        except:
                            pass
            except Exception:
                continue  # Continue with next directory
    except Exception:
        pass  # Ignore errors silently in this context

def get_system_locale():
    """Get system locale"""
    # First try to read from locale.conf
    if os.path.exists('/etc/locale.conf'):
        try:
            with open('/etc/locale.conf', 'r') as f:
                for line in f:
                    if line.startswith('LANG='):
                        return line.split('=')[1].strip().strip('"')
        except:
            pass
    
    # If it doesn't exist or fails, use LANG variable or default to en_US.UTF-8
    return os.getenv('LANG', 'en_US.UTF-8')

def get_language_code():
    """Get system language code and return a valid one"""
    current_locale = get_system_locale()
    
    # If it's C.UTF-8 or similar, use English by default
    if current_locale.startswith('C.') or current_locale == 'C':
        return 'en'
    
    # Get language code (first two letters)
    lang_code = current_locale.split('_')[0]
    
    # Check if code exists in STRINGS, if not, use English
    return lang_code if lang_code in STRINGS else 'en'

# Add this function to check environment
def check_environment():
    """Check and configure necessary environment"""
    # Check user
    if os.getenv('USER') != 'liveuser':
        print("Warning: Not running as liveuser")
    
    # Check critical variables
    required_vars = {
        'DISPLAY': ':0',
        'XAUTHORITY': os.path.expanduser('~/.Xauthority'),
        'XDG_RUNTIME_DIR': f"/run/user/{os.getuid()}",
        'XDG_SESSION_TYPE': 'x11',
        'LANG': os.getenv('LANG', 'en_US.UTF-8')
    }
    
    for var, default in required_vars.items():
        if not os.getenv(var):
            os.environ[var] = default

def diagnose_locale():
    """Diagnose system locale configuration"""
    # print("\n=== Locale Diagnostics ===")
    
    # 1. LANG variable
    # print(f"LANG={os.getenv('LANG', 'not defined')}")
    
    # 2. Content of /etc/default/locale
    try:
        with open('/etc/default/locale', 'r') as f:
            # print("\n/etc/default/locale:")
            # print(f.read().strip())
            pass
    except:
        # print("\n/etc/default/locale: does not exist or not accessible")
        pass
    
    # 3. Generated locales
    try:
        output = subprocess.check_output(['locale', '-a'], text=True)
        # print("\nAvailable locales:")
        # print(output.strip())
    except:
        # print("\nError getting available locales")
        pass
    
    # 4. Current locale status
    try:
        output = subprocess.check_output(['locale'], text=True)
        # print("\nCurrent locale status:")
        # print(output.strip())
    except:
        # print("\nError getting locale status")
        pass
    
    # print("\n==========================")

def set_app_icon():
    """Set application icon silently"""
    try:
        if os.path.exists(ICON_PATH):
            Gtk.Window.set_default_icon_from_file(ICON_PATH)
        else:
            Gtk.Window.set_default_icon_name("system-software-install")
    except:
        Gtk.Window.set_default_icon_name("system-software-install")

class SoplosWelcomeLive(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.soplos.welcomelive",
                        flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.window = None
        self.cleanup_timeout_id = None

    def do_activate(self):
        # Clean AFTER all modules are loaded
        aggressive_cleanup()  # Initial aggressive cleanup
        set_app_icon()   # Set default icon
        if not self.window:
            self.window = MainWindow()
            self.window.set_application(self)
            
            # Set icon using icon theme first
            try:
                icon_theme = Gtk.IconTheme.get_default()
                icon = icon_theme.load_icon("soplos-welcome-live", 128, 0)
                self.window.set_icon(icon)
            except Exception as e:
                # print(f"Error setting icon: {e}")
                # Fallback to local file
                if os.path.exists(ICON_PATH):
                    self.window.set_icon_from_file(ICON_PATH)

            self.window.connect("destroy", lambda x: self.on_quit())
        self.window.show_all()
        
        # Schedule periodic cleanup
        self.cleanup_timeout_id = GLib.timeout_add_seconds(2, self.periodic_cleanup)

    def periodic_cleanup(self):
        """Periodic cleanup every 2 seconds"""
        try:
            aggressive_cleanup()
            return True  # Continue running
        except Exception:
            return False  # Stop if there's an error

    def on_quit(self):
        """Clean cache and close application"""
        try:
            # Cancel timeout if it exists
            if self.cleanup_timeout_id:
                GLib.source_remove(self.cleanup_timeout_id)
                self.cleanup_timeout_id = None
            
            aggressive_cleanup()  # Final cleanup
        except Exception:
            pass  # Ignore cleanup errors
        finally:
            self.quit()

def main():
    try:
        # Register cleanup on program exit
        atexit.register(aggressive_cleanup)
        
        app = SoplosWelcomeLive()
        exit_code = app.run(sys.argv)
        
        # Final cleanup after app terminates
        try:
            aggressive_cleanup()
        except Exception:
            pass  # Ignore final cleanup errors
        
        return exit_code
    except Exception as e:
        # print(f"Error in main: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())