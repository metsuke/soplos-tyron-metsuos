import gi
import webbrowser
import subprocess
import os
import sys

# Add root directory to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GdkPixbuf
from config.strings import STRINGS  # Change import
from config.paths import SLIDE_PATH  # Add SLIDE_PATH import

# Dictionary of languages and their configurations
LANGUAGES = {
    'Español': {'locale': 'es_ES.UTF-8', 'layout': 'es'},
    'English': {'locale': 'en_US.UTF-8', 'layout': 'us'},
    'Português': {'locale': 'pt_PT.UTF-8', 'layout': 'pt'},
    'Français': {'locale': 'fr_FR.UTF-8', 'layout': 'fr'},
    'Deutsch': {'locale': 'de_DE.UTF-8', 'layout': 'de'},
    'Italiano': {'locale': 'it_IT.UTF-8', 'layout': 'it'},
    'Română': {'locale': 'ro_RO.UTF-8', 'layout': 'ro'},
    'Русский': {'locale': 'ru_RU.UTF-8', 'layout': 'ru'}
}

class WelcomeTab(Gtk.ScrolledWindow):
    def __init__(self, parent_window):
        Gtk.ScrolledWindow.__init__(self)
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        self.parent_window = parent_window  # Save reference to main window
        
        self._init_ui()
    
    def _init_ui(self):
        """Initialize user interface"""
        current_lang = self.parent_window.current_lang
        
        # Main container
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        main_box.set_border_width(0)

        try:
            # Use SLIDE_PATH instead of absolute path
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                filename=SLIDE_PATH,  # Use relative path from config.paths
                width=800,
                height=160,
                preserve_aspect_ratio=True
            )
            slide_image = Gtk.Image.new_from_pixbuf(pixbuf)
            main_box.pack_start(slide_image, False, False, 0)  # expand and fill to False
        except Exception as e:
            # Internationalize slide loading error
            print(STRINGS[current_lang]['errors'].get('slide_load', f"Error loading slide: {e}"))
        
        # Welcome message without expand
        welcome_label = Gtk.Label()
        welcome_label.set_markup(
            f"<span size='xx-large' weight='bold'>{STRINGS[current_lang]['live_iso']['title']}</span>\n" +
            f"<span size='large'>{STRINGS[current_lang]['live_iso']['description']}</span>"
        )
        welcome_label.set_line_wrap(True)
        welcome_label.set_justify(Gtk.Justification.CENTER)
        welcome_label.set_margin_top(0)
        welcome_label.set_margin_bottom(0)
        main_box.pack_start(welcome_label, False, False, 0)  # expand and fill to False

        # Container for buttons
        buttons_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        buttons_box.set_margin_top(20)
        buttons_box.set_homogeneous(True)
        main_box.pack_start(buttons_box, False, True, 0)

        # Link buttons with translated texts
        website_button = Gtk.Button(label=STRINGS[current_lang]['buttons']['website'])
        website_button.connect("clicked", lambda x: webbrowser.open("https://soplos.org"))
        buttons_box.pack_start(website_button, True, True, 10)

        forum_button = Gtk.Button(label=STRINGS[current_lang]['buttons']['forums'])
        forum_button.connect("clicked", lambda x: webbrowser.open("https://soplos.org/forums/"))
        buttons_box.pack_start(forum_button, True, True, 10)

        wiki_button = Gtk.Button(label=STRINGS[current_lang]['buttons']['wiki'])
        wiki_button.connect("clicked", lambda x: webbrowser.open("https://soplos.org/wiki/"))
        buttons_box.pack_start(wiki_button, True, True, 10)

        donate_button = Gtk.Button(label=STRINGS[current_lang]['buttons']['donate'])
        donate_button.connect("clicked", lambda x: webbrowser.open("https://paypal.me/isubdes"))
        buttons_box.pack_start(donate_button, True, True, 10)

        self.add(main_box)  # Only add main_box once to ScrolledWindow

    def on_language_changed(self, combo):
        """Handle language change"""
        lang_name = combo.get_active_text()
        lang_config = LANGUAGES[lang_name]
        
        try:
            # Generate and apply locale
            subprocess.run(['pkexec', 'locale-gen', lang_config['locale']], check=True)
            subprocess.run(['pkexec', 'update-locale', f"LANG={lang_config['locale']}"], check=True)
            
            # Configure keyboard layout
            # First for current session
            subprocess.run(['setxkbmap', lang_config['layout']], check=True)
            
            # Make change permanent
            xorg_conf = f"""Section "InputClass"
        Identifier "system-keyboard"
        MatchIsKeyboard "on"
        Option "XkbLayout" "{lang_config['layout']}"
EndSection"""
            
            # Create directory if it doesn't exist
            os.makedirs("/etc/X11/xorg.conf.d", exist_ok=True)
            
            # Write configuration
            subprocess.run(['pkexec', 'bash', '-c', 
                          f'echo \'{xorg_conf}\' > /etc/X11/xorg.conf.d/00-keyboard.conf'],
                         check=True)
            
            # Restart LightDM
            subprocess.run(['pkexec', 'systemctl', 'restart', 'lightdm'], check=True)
            
        except subprocess.CalledProcessError as e:
            # Internacionalizar error de configuración de idioma
            print(STRINGS[self.parent_window.current_lang]['errors'].get('language_config', f"Error configuring language: {e}"))
